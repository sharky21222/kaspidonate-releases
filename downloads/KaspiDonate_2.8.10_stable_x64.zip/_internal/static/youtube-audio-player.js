(function () {
    'use strict';

    function create({ host, videoId, requestId = '', startSeconds = 0, paused = false, volume, onPlaying, onEnded, onError, onFallback }) {
        let controller = null;
        const media = document.createElement('audio');
        // Keep the shared transport/volume code on its existing media-element ID.
        media.id = 'ytvideo';
        media.dataset.audioOnly = '1';
        media.dataset.youtubeVideoId = videoId;
        media.dataset.youtubeRequestId = requestId;
        media.dataset.shouldPlay = paused ? '0' : '1';
        media.preload = 'auto';
        media.controls = false;
        host.replaceChildren(media);
        let closed = false;
        let state = 3;
        let retries = 0;
        let retryTimer = null;
        let initialPositionApplied = false;
        let limitTimer = null;
        let recoveryTimer = null;
        let recoveries = 0;
        let generation = 0;
        let loading = false;
        let resumePosition = Math.max(0, Number(startSeconds) || 0);
        let lastProgressAt = Date.now();
        let lastPosition = resumePosition;
        let progressTimer = setInterval(() => {
            if (closed || loading || media.dataset.shouldPlay !== '1' || !media.getAttribute('src')) return;
            const position = Number(media.currentTime) || 0;
            if (position > lastPosition + .05) lastProgressAt = Date.now();
            lastPosition = position;
            if (Date.now() - lastProgressAt >= 15000) recover('Аудиопоток YouTube перестал загружаться');
        }, 1000);
        const clearTimers = () => {
            clearTimeout(limitTimer);
            clearTimeout(retryTimer);
            limitTimer = retryTimer = null;
        };
        function dispose() {
            if (closed) return;
            closed = true;
            resumePosition = Number(media.currentTime) || lastPosition || resumePosition;
            clearTimers();
            clearTimeout(recoveryTimer);
            clearInterval(progressTimer);
            controller?.abort();
            media.dataset.shouldPlay = '0';
            media.pause();
            media.removeAttribute('src');
            media.load();
            media.remove();
        }
        function fail(message) {
            if (closed) return;
            dispose();
            onError(message);
        }
        function fallback(message) {
            if (closed) return;
            if (!onFallback) { recover(message); return; }
            const position = Number(media.currentTime) || lastPosition || resumePosition;
            const isPaused = media.dataset.shouldPlay === '0';
            dispose();
            onFallback(message, position, isPaused);
        }
        function recover(message) {
            if (closed || recoveryTimer) return;
            resumePosition = Number(media.currentTime) || lastPosition || resumePosition;
            if (recoveries >= 2) { fail(message); return; }
            ++recoveries;
            ++generation;
            loading = true;
            state = 3;
            clearTimers();
            controller?.abort();
            media.pause();
            console.warn('YouTube audio reconnect:', videoId, recoveries, message);
            recoveryTimer = setTimeout(() => {
                recoveryTimer = null;
                loadStream(true);
            }, recoveries * 1000);
        }
        function applyVolume() {
            media.volume = Math.max(0, Math.min(1, Number(volume()) || 0));
            media.muted = media.volume === 0;
        }
        function play() {
            if (closed || loading || media.dataset.shouldPlay !== '1' || !media.getAttribute('src')) return;
            const attempt = generation;
            applyVolume();
            media.play().catch(error => {
                if (closed || attempt !== generation || media.dataset.shouldPlay !== '1' || error.name === 'AbortError') return;
                if (error.name === 'NotAllowedError' && ++retries < 5) {
                    clearTimeout(retryTimer);
                    retryTimer = setTimeout(play, 800);
                } else recover('Не удалось воспроизвести аудиопоток YouTube: ' + error.name + ': ' + error.message);
            });
        }
        media.addEventListener('loadedmetadata', () => {
            if (closed || loading) return;
            if (!initialPositionApplied) {
                initialPositionApplied = true;
                if (resumePosition > 0) media.currentTime = Math.min(resumePosition, Math.max(0, (media.duration || Infinity) - .1));
            }
            lastPosition = Number(media.currentTime) || 0;
            lastProgressAt = Date.now();
            if (media.dataset.shouldPlay === '0') { state = 2; clearTimers(); }
            else play();
        });
        media.addEventListener('playing', () => {
            if (closed || loading) return;
            state = 1;
            lastProgressAt = Date.now();
            clearTimers();
            onPlaying();
        });
        media.addEventListener('pause', () => { if (!closed && !loading) state = 2; });
        media.addEventListener('waiting', () => { if (!closed && !loading) state = 3; });
        media.addEventListener('ended', () => {
            if (closed || loading) return;
            state = 0;
            dispose();
            onEnded();
        });
        media.addEventListener('error', () => {
            if (!loading) recover('Ошибка аудиопотока YouTube (код ' + (media.error?.code || 0) + ')');
        });
        function loadStream(refresh = false) {
            if (closed) return;
            const attempt = ++generation;
            controller?.abort();
            controller = new AbortController();
            loading = true;
            initialPositionApplied = false;
            limitTimer = setTimeout(() => fallback('Не удалось загрузить аудиопоток YouTube'), onFallback ? 12000 : 45000);
            fetch('/api/yt_stream/' + encodeURIComponent(videoId) + '?audio_only=1' + (refresh ? '&refresh=1' : ''), { cache: 'no-store', signal: controller.signal })
            .then(response => {
                if (response.ok === false) throw new Error('HTTP ' + response.status);
                return response.json();
            })
            .then(data => {
                if (closed || generation !== attempt) return;
                if (!data || data.audio_only !== true || data.video_url || !data.audio_url) {
                    fallback('YouTube не предоставил аудиопоток: ' + (data?.error || 'empty stream'));
                    return;
                }
                const url = new URL(data.audio_proxy_url || data.audio_url, location.href);
                if (!['http:', 'https:'].includes(url.protocol)) throw new Error('Invalid audio URL');
                if (refresh && data.audio_proxy_url) url.searchParams.set('retry', Date.now() + '-' + attempt);
                applyVolume();
                loading = false;
                lastProgressAt = Date.now();
                media.src = url.href;
                media.load();
            }).catch(error => {
                if (!closed && generation === attempt && error.name !== 'AbortError')
                    recover('Не удалось получить аудиопоток YouTube: ' + error.message);
            });
        }
        loadStream();
        return {
            _video: media,
            getIframe: () => media,
            getPlayerState: () => state,
            getCurrentTime: () => closed || loading || !initialPositionApplied ? resumePosition : media.currentTime || 0,
            getDuration: () => Number.isFinite(media.duration) ? media.duration : 0,
            playVideo: () => {
                if (media.dataset.shouldPlay !== '1') lastProgressAt = Date.now();
                media.dataset.shouldPlay = '1'; play();
            },
            pauseVideo: () => {
                media.dataset.shouldPlay = '0'; state = 2; media.pause();
            },
            stopVideo: dispose,
            destroy: dispose,
            seekTo: seconds => {
                if (media.readyState > 0) media.currentTime = resumePosition = lastPosition = Math.max(0, Number(seconds) || 0);
            },
            setVolume: value => { media.volume = Math.max(0, Math.min(1, value / 100)); },
            mute: () => { media.muted = true; },
            unMute: applyVolume,
            setPlaybackQuality: () => {},
        };
    }

    window.KaspiYoutubeAudioPlayer = { create };
})();
