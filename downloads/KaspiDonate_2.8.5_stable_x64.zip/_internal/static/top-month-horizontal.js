(function () {
    'use strict';

    const runtime = window.KaspiWidgetRuntime;
    const container = document.getElementById('container');
    const title = document.getElementById('title');
    const titleText = document.getElementById('monthHorizontalTitleText');
    const list = document.getElementById('list');
    const panelPreview = new URLSearchParams(location.search).get('panel_preview') === '1';
    let config = {};
    let lastRowsKey = null;
    let lastStructureKey = null;
    let request = null;
    let switchingTemplate = false;

    if (panelPreview) document.documentElement.classList.add('panel-preview');

    function escapeHtml(value) {
        return String(value ?? '').replace(/[&<>"']/g, function (char) {
            return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[char];
        });
    }

    function fitScale() {
        const scale = panelPreview
            ? Math.min(1, Math.max(.2, (window.innerWidth - 28) / 640))
            : Math.max(.5, Math.min(3, Number(config.scale) || 1));
        if (scale === 1) {
            if (container.style.transform) container.style.removeProperty('transform');
            return;
        }
        const transform = 'scale(' + scale + ')';
        if (container.style.transform !== transform) container.style.transform = transform;
    }

    function fitTitle() {
        const style = getComputedStyle(title);
        const padding = parseFloat(style.paddingLeft) + parseFloat(style.paddingRight);
        const context = document.createElement('canvas').getContext('2d');
        context.font = style.fontWeight + ' 33px ' + style.fontFamily;
        const textWidth = context.measureText(titleText.textContent).width;
        const labelWidth = Math.max(246, Math.min(344, Math.ceil(textWidth + padding + 3)));
        const available = labelWidth - padding;
        const size = Math.max(18, Math.min(33, Math.floor(33 * available / Math.max(textWidth, 1))));
        container.style.setProperty('--month-label-width', labelWidth + 'px');
        title.style.setProperty('font-size', size + 'px', 'important');
    }

    function animationPhase(loop) {
        const group = loop && loop.querySelector('.month-horizontal-group');
        const animation = group && group.getAnimations()[0];
        const progress = animation?.effect?.getComputedTiming().progress;
        if (!Number.isFinite(progress)) return 0;
        return (((progress - .5) * 2) % 1 + 1) % 1;
    }

    function syncDuration(phase, distance) {
        const loop = list.querySelector('.month-horizontal-loop');
        const group = loop && loop.querySelector('.month-horizontal-group');
        if (!loop || !group) return;
        const width = group.scrollWidth;
        const position = Number.isFinite(distance)
            ? ((distance / width) % 1 + 1) % 1
            : phase === undefined ? animationPhase(loop) : phase;
        const duration = Math.max(16, width * 2 / 95);
        loop.style.setProperty('--month-horizontal-duration', duration.toFixed(2) + 's');
        loop.style.setProperty('--month-horizontal-half-delay', (-duration / 2).toFixed(2) + 's');
        loop.querySelectorAll('.month-horizontal-group').forEach(function (item) {
            const animation = item.getAnimations()[0];
            if (animation) animation.currentTime = position * duration * 500;
        });
    }

    function renderRows(data) {
        const phase = animationPhase(list.querySelector('.month-horizontal-loop'));
        if (!data.length) {
            list.innerHTML = '<div class="month-horizontal-empty">ОЖИДАЕМ ДОНАТЕРОВ</div>';
            return;
        }
        const rows = data.map(function (item, index) {
            const name = escapeHtml(item.sender || 'Аноним');
            const amount = escapeHtml(Math.round(Number(item.amount) || 0).toLocaleString('ru-RU'));
            const currency = escapeHtml(item.currency || '₸');
            return '<div class="month-horizontal-item">'
                + '<span class="month-horizontal-name"><b>' + (index + 1) + '.</b> ' + name + '</span>'
                + '<span class="month-horizontal-amount"><span class="month-horizontal-value">' + amount + '</span>'
                + ' <span class="month-horizontal-currency">' + currency + '</span></span>'
                + '</div>';
        });
        const repeated = rows.join('').repeat(Math.ceil(3 / rows.length));
        list.innerHTML = '<div class="month-horizontal-loop"><div class="month-horizontal-group">'
            + repeated + '</div><div class="month-horizontal-group" aria-hidden="true">'
            + repeated + '</div></div>';
        requestAnimationFrame(function () {
            if (list.isConnected && runtime.active(['top'])) syncDuration(phase);
        });
    }

    function updateAmounts(data) {
        const loop = list.querySelector('.month-horizontal-loop');
        const group = loop && loop.querySelector('.month-horizontal-group');
        const values = loop && loop.querySelectorAll('.month-horizontal-value');
        if (!group || !data.length || !values.length || values.length % data.length) return false;
        const amounts = data.map(function (item) {
            return Math.round(Number(item.amount) || 0).toLocaleString('ru-RU');
        });
        if (Array.from(values).every(function (value, index) {
            return value.textContent === amounts[index % amounts.length];
        })) return true;
        const oldWidth = group.scrollWidth;
        const distance = animationPhase(loop) * oldWidth;
        values.forEach(function (value, index) {
            const amount = amounts[index % amounts.length];
            if (value.textContent !== amount) value.textContent = amount;
        });
        if (group.scrollWidth !== oldWidth) syncDuration(undefined, distance);
        return true;
    }

    function applyPayload(payload) {
        if (!payload || payload.status !== 'ok') return;
        if (payload.config?.template !== 'horizontal') {
            if (!switchingTemplate) {
                switchingTemplate = true;
                location.reload();
            }
            return;
        }
        config = payload.config;
        const palette = String(config.horizontal_palette || 'gold');
        const safePalette = ['gold', 'mint', 'coral', 'ice', 'red'].includes(palette) ? palette : 'gold';
        if (container.dataset.palette !== safePalette) container.dataset.palette = safePalette;
        const label = String(config.horizontal_title || 'ТОП МЕСЯЦА')
            .replace(/^[🏆👑🦈]\s*/u, '').trim().replace(/:\s*$/, '') || 'ТОП МЕСЯЦА';
        const nextTitle = label + ':';
        if (titleText.textContent !== nextTitle) {
            titleText.textContent = nextTitle;
            fitTitle();
        }
        fitScale();

        const donors = (Array.isArray(payload.data) ? payload.data : []).slice(0, 10);
        const rowsKey = JSON.stringify(donors.map(function (item) {
            return [item.sender, Math.round(Number(item.amount) || 0), item.currency || '₸'];
        }));
        if (rowsKey !== lastRowsKey) {
            const structureKey = JSON.stringify(donors.map(function (item) {
                return [item.sender, item.currency || '₸'];
            }));
            if (structureKey !== lastStructureKey || !updateAmounts(donors)) renderRows(donors);
            lastStructureKey = structureKey;
            lastRowsKey = rowsKey;
        }
    }

    async function loadData() {
        if (request || switchingTemplate || !runtime.active(['top'])) return;
        const controller = new AbortController();
        request = controller;
        const timeout = setTimeout(function () { controller.abort(); }, 6000);
        try {
            const response = await fetch('/api/top_month_data', {
                cache: 'no-store', signal: controller.signal,
            });
            if (!response.ok) return;
            const payload = await response.json();
            if (runtime.active(['top'])) applyPayload(payload);
        } catch (_) {
            // A missed poll leaves the current strip moving; the next poll retries.
        } finally {
            clearTimeout(timeout);
            if (request === controller) request = null;
        }
    }

    window.KaspiTopMonthHorizontal = { refresh: loadData };
    fitScale();
    fitTitle();
    runtime.every(loadData, 4000, ['top'], true);
    runtime.subscribe(function (active) {
        if (active) loadData();
        else if (request) {
            request.abort();
            request = null;
        }
    });
    window.addEventListener('obsSourceVisibleChanged', function (event) {
        document.documentElement.classList.toggle('month-source-hidden', event.detail?.visible === false);
    });
    window.addEventListener('resize', fitScale);
    if (document.fonts && document.fonts.ready) {
        document.fonts.ready.then(function () {
            fitTitle();
            syncDuration();
        }).catch(function () {});
    }
})();
