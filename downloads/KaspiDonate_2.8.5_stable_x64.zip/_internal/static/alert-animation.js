(function (global) {
    'use strict';
    const SOURCE = '/static/alerts/SHARKY_Original_Motion.webm';
    const WIDTH = 1672;
    const HEIGHT = 720;
    let active = null;

    function enabled(config, donation) {
        return config?.template === 'sharky_motion' && donation?.alert_type !== 'voice_message';
    }

    function stop() {
        if (active) active.finish('cancelled');
    }

    function ensureScene(host) {
        let scene = host.querySelector('.sharky-alert-scene');
        if (scene) return scene;
        scene = document.createElement('div');
        scene.className = 'sharky-alert-scene';
        const video = document.createElement('video');
        video.className = 'sharky-alert-video';
        video.playsInline = true;
        video.preload = 'auto';
        video.loop = false;
        video.src = SOURCE;
        const text = document.createElement('div');
        text.className = 'sharky-alert-text';
        for (const name of ['amount', 'sender', 'comment']) {
            const item = document.createElement('div');
            item.className = 'sharky-alert-' + name;
            text.appendChild(item);
        }
        scene.appendChild(video);
        scene.appendChild(text);
        host.appendChild(scene);
        return scene;
    }

    function play({ host, donation, comment = '', volume = 1, muted = false }) {
        stop();
        const scene = ensureScene(host);
        const video = scene.querySelector('video');
        const amount = scene.querySelector('.sharky-alert-amount');
        const sender = scene.querySelector('.sharky-alert-sender');
        const message = scene.querySelector('.sharky-alert-comment');
        const value = Number(donation.amount);
        amount.textContent = `${(Number.isFinite(value) ? value : 0).toLocaleString('ru-RU', { maximumFractionDigits: 2 })} ${donation.currency || '\u20b8'}`;
        sender.textContent = donation.sender || '\u0410\u043d\u043e\u043d\u0438\u043c';
        message.textContent = comment;
        video.muted = muted || !!global.__KASPI_PREVIEW__;
        video.volume = Number.isFinite(Number(volume)) ? Math.max(0, Math.min(1, Number(volume))) : 1;
        video.playbackRate = 1;
        video.currentTime = 0;
        host.style.animation = 'none';
        host.classList.add('sharky-animation-active');
        host.classList.remove('hidden');

        const fit = () => {
            // The combined overlay has body zoom; fit physical viewport pixels.
            let zoom = 1;
            for (let parent = host.parentElement; parent; parent = parent.parentElement) {
                zoom *= Number.parseFloat(global.getComputedStyle(parent).zoom) || 1;
            }
            const scale = Math.max(0.01, Math.min(1, (global.innerWidth - 24) / (WIDTH * zoom), (global.innerHeight - 24) / (HEIGHT * zoom)));
            host.style.setProperty('--sharky-scale', String(scale));
            amount.style.fontSize = '82px';
            let size = 82;
            while (amount.scrollWidth > amount.clientWidth && size > 20) {
                size -= 2;
                amount.style.fontSize = `${size}px`;
            }
        };
        fit();
        global.addEventListener('resize', fit);

        return new Promise((resolve) => {
            let finished = false;
            let watchdog = null;
            const finish = (reason) => {
                if (finished) return;
                finished = true;
                clearTimeout(watchdog);
                video.removeEventListener('ended', onEnded);
                video.removeEventListener('error', onError);
                video.removeEventListener('playing', onPlaying);
                global.removeEventListener('resize', fit);
                video.pause();
                video.currentTime = 0;
                host.classList.add('hidden');
                host.classList.remove('sharky-animation-active');
                if (active?.finish === finish) active = null;
                resolve(reason);
            };
            const onEnded = () => finish('ended');
            const onError = () => {
                if (finished) return;
                console.warn('SHARKY alert media error', video.error?.code);
                clearTimeout(watchdog);
                // Keep the amount visible briefly when media fails.
                watchdog = setTimeout(() => finish('error'), 3000);
            };
            const onPlaying = () => {
                if (finished) return;
                clearTimeout(watchdog);
                const duration = Number.isFinite(video.duration) ? video.duration : 8;
                watchdog = setTimeout(() => finish('timeout'), Math.min(30000, (duration + 5) * 1000));
            };
            active = { finish, video };
            video.addEventListener('ended', onEnded);
            video.addEventListener('error', onError);
            video.addEventListener('playing', onPlaying);
            watchdog = setTimeout(() => finish('timeout'), 20000);
            video.play().catch((error) => {
                if (finished) return;
                if (error.name === 'NotAllowedError' && !video.muted) {
                    console.warn('SHARKY audio autoplay blocked; playing muted');
                    video.muted = true;
                    video.play().catch(onError);
                } else onError();
            });
        });
    }

    function setVolume(volume) {
        if (!active) return;
        const value = Number(volume);
        if (Number.isFinite(value)) active.video.volume = Math.max(0, Math.min(1, value));
    }

    global.KaspiAlertAnimation = { enabled, play, stop, setVolume };
})(window);
