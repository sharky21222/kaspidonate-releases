(function () {
    'use strict';
    let signature = '', configSignature = '';
    function render(donation) {
        const host = document.getElementById('lastDonationItem');
        if (!host) return;
        const sender = String(donation?.sender || (donation ? '\u0410\u043d\u043e\u043d\u0438\u043c' : '\u041d\u0435\u0442 \u0434\u043e\u043d\u0430\u0442\u043e\u0432'));
        const currency = String(donation?.currency || '\u20b8');
        const value = Number(donation?.amount || 0);
        const amount = (Number.isFinite(value) ? value : 0).toLocaleString('ru-RU', { maximumFractionDigits: 2 }) + ' ' + currency;
        const comment = String(donation?.comment || '').replace(/\bVM-[ABCDEFGHJKMNPQRSTUVWXYZ23456789]{6}\b/gi, '').trim();
        const next = JSON.stringify([sender, amount, comment]);
        if (signature === next) return;
        signature = next;
        const name = document.createElement('div'); name.className = 'last-donation-sender'; name.textContent = sender; name.title = sender;
        const sum = document.createElement('div'); sum.className = 'last-donation-amount'; sum.textContent = amount;
        const message = document.createElement('div'); message.className = 'last-donation-comment'; message.textContent = comment; message.title = comment; message.hidden = !comment;
        host.replaceChildren(name, sum, message);
    }
    function configure(config = {}) {
        const column = document.querySelector('.right-column');
        if (!column) return;
        const next = JSON.stringify([config.last_donation_style, config.last_gradient, config.last_donation_title, config.last_title_size, config.nick_font_family]);
        if (next === configSignature) return;
        configSignature = next;
        Array.from(column.classList).filter(name => name.startsWith('last-')).forEach(name => column.classList.remove(name));
        if ((config.last_donation_style || 'leaderboard') === 'leaderboard') column.classList.add('last-leaderboard');
        const themes = ['sunset', 'ocean', 'emerald', 'purple', 'fire', 'rainbow', 'amethyst', 'pink', 'cosmic', 'neon', 'dark', 'grape'];
        if (themes.includes(config.last_gradient)) column.classList.add('last-' + config.last_gradient);
        if (column.classList.contains('widget-container')) {
            Array.from(column.classList).filter(name => name.startsWith('theme-')).forEach(name => column.classList.remove(name));
            if (themes.includes(config.last_gradient)) column.classList.add('theme-' + config.last_gradient);
        }
        column.querySelector('.last-donation-title').textContent = config.last_donation_title || '\u041d\u0415\u0414\u0410\u0412\u041d\u0418\u0419';
        column.style.setProperty('--last-title-size', Math.max(14, Math.min(32, Number(config.last_title_size) || 24)) + 'px');
        column.style.setProperty('--title-size', Math.max(14, Math.min(40, Number(config.last_title_size) || 24)) + 'px');
    }
    function start() {
        let pending = false;
        async function update() {
            if (pending || !window.KaspiWidgetRuntime.active(['last'])) return;
            pending = true;
            const controller = new AbortController();
            const timeout = setTimeout(() => controller.abort(), 6000);
            try {
                const response = await fetch('/api/last_donation', { cache: 'no-store', signal: controller.signal });
                if (!response.ok) return;
                const data = await response.json();
                if (!window.KaspiWidgetRuntime.active(['last'])) return;
                configure(data.top_config);
                render((data.donations || []).slice(-1)[0]);
            } catch (_) {} finally { clearTimeout(timeout); pending = false; }
        }
        window.KaspiWidgetRuntime.every(update, 3000, ['last'], true);
    }
    window.KaspiLastDonation = { render, configure, start };
})();
