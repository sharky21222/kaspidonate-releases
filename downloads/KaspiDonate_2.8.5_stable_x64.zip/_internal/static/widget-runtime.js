(function () {
    'use strict';
    const jobs = new Set(), listeners = new Set();
    let sourceVisible = true, disposed = false;
    function view() {
        const query = new URLSearchParams(location.search);
        if (query.has('goal_only')) return 'goal';
        if (query.has('kaspi_only')) return 'donatel';
        if (query.has('alert_only')) return 'alert';
        if (['/last', '/alert'].includes(location.pathname)) return 'last';
        if (location.pathname === '/top_month') return 'top';
        if (['/ticker', '/ticker_amir'].includes(location.pathname)) return 'month';
        const hash = location.hash.slice(1).toLowerCase();
        return hash === 'main' ? '' : hash;
    }
    function shows(name) {
        const current = view();
        return current ? current === name : !['last', 'youtube', 'profile', 'timer', 'advst'].includes(name);
    }
    function active(views = ['*']) {
        // A background browser surface can still be the stream's music source.
        const backgroundAudio = view() === 'youtube' && !window.__KASPI_PREVIEW__;
        return !disposed && sourceVisible && (!document.hidden || backgroundAudio) &&
            (views.includes('*') || views.some(shows));
    }
    function reconcile(job) {
        if (active(job.views)) {
            if (!job.timer) {
                job.timer = setInterval(job.fn, job.ms);
                if (job.immediate) job.fn();
            }
        } else if (job.timer) {
            clearInterval(job.timer); job.timer = 0;
        }
    }
    function every(fn, ms, views, immediate = false) {
        const job = { fn, ms, views, immediate, timer: 0 };
        jobs.add(job); reconcile(job);
        return () => { clearInterval(job.timer); jobs.delete(job); };
    }
    function sync() {
        document.documentElement.classList.toggle('widget-suspended', !active());
        jobs.forEach(reconcile);
        listeners.forEach(fn => fn(active()));
    }
    window.KaspiWidgetRuntime = { view, shows, active, every,
        subscribe(fn) { listeners.add(fn); return () => listeners.delete(fn); } };
    document.documentElement.setAttribute('data-view', view());
    document.addEventListener('visibilitychange', sync);
    window.addEventListener('obsSourceVisibleChanged', event => { sourceVisible = event.detail?.visible !== false; sync(); });
    window.addEventListener('pageshow', () => { disposed = false; sync(); });
    window.addEventListener('pagehide', () => { disposed = true; sync(); });
    // A new source selection gets fresh controllers and releases all old decoders.
    window.addEventListener('hashchange', () => { disposed = true; sync(); location.reload(); });
})();
