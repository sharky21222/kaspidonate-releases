(function (root) {
    'use strict';
    const fields = {
        transparent: [['bank_kaspi_seconds', 5], ['bank_tbank_seconds', 5]],
        kaspi_banks: [['banks_kaspi_seconds', 6], ['banks_tbank_seconds', 1], ['banks_alif_seconds', 1], ['banks_dc_seconds', 6]],
    };
    const original = new WeakMap(), applied = new WeakMap(), overridden = new WeakSet();
    let latest = null;
    function cssFrames(animation) {
        if (!root?.document) return null;
        // CSSOM retains var() expressions; getKeyframes() resolves them to old pixel sizes.
        for (const sheet of root.document.styleSheets) {
            let rules;
            try { rules = sheet.cssRules; } catch (_) { continue; }
            for (const rule of rules || []) {
                if (rule.type !== root.CSSRule.KEYFRAMES_RULE || rule.name !== animation.animationName) continue;
                const easing = root.getComputedStyle(animation.effect.target).animationTimingFunction;
                return [...rule.cssRules].flatMap(frame => frame.keyText.split(',').map(key => ({
                    offset: parseFloat(key) / 100, opacity: frame.style.opacity,
                    ...(frame.style.transform ? { transform: frame.style.transform } : {}),
                    easing: frame.style.animationTimingFunction || easing,
                }))).sort((a, b) => a.offset - b.offset);
            }
        }
        return null;
    }
    function seconds(value, fallback) {
        if (!['number', 'string'].includes(typeof value) || String(value).trim() === '') return fallback;
        const number = Number(value);
        return Number.isFinite(number) ? Math.round(Math.max(.2, Math.min(120, number)) * 10) / 10 : fallback;
    }
    function values(style, template) {
        return (fields[template] || []).map(([key, fallback]) => seconds(style[key], fallback));
    }
    function buildPlan(style, template) {
        const v = values(style, template);
        if (!v.length) return null;
        const custom = fields[template].some(([key]) => Object.hasOwn(style, key));
        const frames = (total, points) => points.map(([time, opacity, transform]) => ({
            offset: Math.max(0, Math.min(1, time / total)), opacity,
            ...(transform ? { transform } : {}), easing: 'cubic-bezier(.22,.7,.3,1)',
        }));
        if (template === 'transparent') {
            const [kaspi, tbank] = v, cross = kaspi + 1, end = cross + tbank, total = end + 1;
            return { custom, duration: total * 1000, frames: {
                kaspiBankPrimary: frames(total, [[0,1],[kaspi,1],[cross,0],[end,0],[total,1]]),
                kaspiBankSecondary: frames(total, [[0,0],[kaspi,0],[cross,1],[end,1],[total,0]]),
            } };
        }
        const [kaspi, tbank, alif, dc] = v;
        const cross = kaspi + .8, tEnd = cross + tbank, aIn = tEnd + .8;
        const aEnd = aIn + alif, dIn = aEnd + .8, dEnd = dIn + dc;
        const retract = dEnd + 1, total = retract + .6;
        const still = 'translate3d(0,0,0)', hidden = 'translate3d(-8px,0,0)';
        const bankIn = 'translate3d(0,0,0) scale(1)', bankOut = 'translate3d(6px,0,0) scale(.94)';
        const bankUp = 'translate3d(0,calc(0px - var(--kb-lift)),0) scale(1)';
        const folded = 'translate3d(0,0,0) scale(.22)';
        const spread = 'translate3d(var(--kb-travel),var(--kb-drop),0) scale(1)';
        return { custom, duration: total * 1000, phases: { kaspi, cross, tEnd, aIn, aEnd, dIn, dEnd, retract, total }, frames: {
            kbPrimary: frames(total, [[0,1,still],[kaspi,1,still],[cross,0,hidden],[retract,0,hidden],[total,1,still]]),
            kbTbank: frames(total, [[0,0,bankOut],[kaspi,0,bankOut],[cross,1,bankIn],[tEnd,1,bankIn],[aIn,1,bankUp],[retract,1,bankUp],[total,0,bankOut]]),
            kbProfile: frames(total, [[0,0,'translate3d(8px,0,0)'],[kaspi,0,'translate3d(8px,0,0)'],[cross,1,still],[retract,1,still],[total,0,'translate3d(8px,0,0)']]),
            kbAlif: frames(total, [[0,0,folded],[tEnd,0,folded],[aIn,1,spread],[dEnd,1,spread],[retract,0,folded],[total,0,folded]]),
            kbDC: frames(total, [[0,0,folded],[aEnd,0,folded],[dIn,1,spread],[dEnd,1,spread],[retract,0,folded],[total,0,folded]]),
        } };
    }
    function configure(style, host) {
        const template = style?.template;
        if (!host || !fields[template]) { latest = null; return; }
        latest = { style, host };
        const plan = buildPlan(style, template);
        const animations = host.getAnimations({ subtree: true }).filter(animation => plan.frames[animation.animationName]);
        const geometry = template === 'kaspi_banks' ? [style.icon_size, style.tbank_icon_size, style.alif_icon_size, style.dc_icon_size] : [];
        const signature = JSON.stringify([template, plan.custom, values(style, template), geometry]);
        const previous = applied.get(host);
        if (previous?.signature === signature && animations.length === previous.animations.length && animations.every(a => previous.animations.includes(a))) return;
        const first = animations[0];
        const oldDuration = Number(first?.effect.getTiming().duration) || plan.duration;
        const phase = ((Number(first?.currentTime) || 0) % oldDuration) / oldDuration;
        for (const animation of animations) {
            if (!original.has(animation)) original.set(animation, { frames: cssFrames(animation) || animation.effect.getKeyframes(), timing: animation.effect.getTiming() });
            const saved = original.get(animation);
            if (plan.custom) {
                animation.effect.setKeyframes(plan.frames[animation.animationName]);
                animation.effect.updateTiming({ duration: plan.duration, easing: 'linear' });
                animation.currentTime = phase * plan.duration;
                overridden.add(animation);
            } else if (overridden.has(animation)) {
                animation.effect.setKeyframes(saved.frames);
                animation.effect.updateTiming(saved.timing);
                animation.currentTime = phase * Number(saved.timing.duration);
            }
        }
        applied.set(host, { signature, animations });
    }
    const api = { fields, seconds, values, buildPlan, configure };
    if (typeof module !== 'undefined' && module.exports) module.exports = api;
    if (root?.addEventListener) {
        root.KaspiTiming = api;
        root.matchMedia?.('(prefers-reduced-motion: reduce)').addEventListener('change', () => {
            if (latest?.host.isConnected) configure(latest.style, latest.host);
        });
        root.addEventListener('pagehide', () => { latest = null; });
    }
})(typeof window !== 'undefined' ? window : null);
