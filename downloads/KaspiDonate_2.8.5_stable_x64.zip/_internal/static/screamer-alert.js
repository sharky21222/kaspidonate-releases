(function (root, factory) {
    const screamer = factory(root);
    if (typeof module === 'object' && module.exports) module.exports = screamer;
    if (root) root.KaspiScreamerAlert = screamer;
})(typeof window !== 'undefined' ? window : null, function (root) {
    'use strict';

    const library = root?.KaspiScreamerLibrary || (typeof require === 'function' ? require('./screamer-library.js') : null);
    const { sounds, activeSounds, urlForSound } = library;
    const sequenceKey = 'kaspi.screamer.lastSound.v1';
    let previous = null;
    try { previous = root?.localStorage?.getItem(sequenceKey) || null; } catch (_) {}

    let bag = [];
    let bagPool = '';

    function pick(config, amount, currency, isVoiceAlert, assignedSound) {
        if (config?.enabled !== true || isVoiceAlert) return null;
        const code = String(currency || '').trim().toUpperCase();
        const target = Number(
            code === '₸' || code === 'KZT' ? config.amount_kzt
                : code === '₽' || code === 'RUB' || code === 'RUR' ? config.amount_rub
                    : code === 'TJS' || code === 'C' || code === '\u0421' ? config.amount_tjs : 0
        );
        const paid = Number(amount);
        if (!Number.isFinite(target) || target < 1 || !Number.isFinite(paid) || paid !== target) return null;

        const assigned = !!urlForSound(assignedSound, config);
        const pool = activeSounds(config);
        if (!pool.length) return null;
        let fallback = pool[(pool.indexOf(previous) + 1) % pool.length];
        if (!assigned && config.mode === 'shuffle') {
            const key = pool.join('|');
            if (!bag.length || key !== bagPool) {
                bagPool = key;
                bag = pool.slice();
                for (let i = bag.length - 1; i > 0; --i) {
                    const j = Math.floor(Math.random() * (i + 1));
                    [bag[i], bag[j]] = [bag[j], bag[i]];
                }
                if (bag.length > 1 && bag[bag.length - 1] === previous) [bag[0], bag[bag.length - 1]] = [bag[bag.length - 1], bag[0]];
            }
            fallback = root?.__KASPI_PREVIEW__ ? bag[bag.length - 1] : bag.pop();
        }
        const sound = assigned ? assignedSound : fallback;
        // Live donations use the server's cursor; only standalone tests need a local one.
        if (!assigned && !root?.__KASPI_PREVIEW__) {
            previous = sound;
            try { root?.localStorage?.setItem(sequenceKey, sound); } catch (_) {}
        }
        return {
            sound,
            url: urlForSound(sound, config),
            screamer: true,
            volume: library.volumeForSound(sound, config)
        };
    }

    return { sounds, activeSounds, pick, urlForSound };
});
