(function () {
    'use strict';
    let banner = null, stage = null, observer = null, fitJob = 0;
    let phoneValue = null, profileValue = null;
    function fit() {
        fitJob = 0;
        if (!stage?.isConnected) return;
        let zoom = 1;
        for (let node = banner; node; node = node.parentElement) {
            const value = parseFloat(getComputedStyle(node).zoom);
            if (Number.isFinite(value) && value > 0) zoom *= value;
        }
        const availableHeight = Math.max(16, innerHeight - banner.getBoundingClientRect().top - 12);
        banner.style.setProperty('--kb-fit', Math.max(.02, Math.min(1.6,
            (innerWidth - 24) / ((stage.offsetWidth + 12) * zoom),
            availableHeight / ((stage.offsetHeight + 10) * zoom))));
    }
    function scheduleFit() { if (!fitJob && stage) fitJob = requestAnimationFrame(fit); }
    function dispose() {
        observer?.disconnect(); observer = null;
        cancelAnimationFrame(fitJob); fitJob = 0;
        stage?.remove(); stage = null;
        banner?.style.removeProperty('--kb-fit');
        banner = null; phoneValue = profileValue = null;
    }
    function configure(style, host = document.querySelector('.kaspi-banner')) {
        if (style?.template !== 'kaspi_banks' || !host) { dispose(); return; }
        if (banner !== host) dispose();
        banner = host;
        const icon = Math.max(24, Math.min(120, Number(style.icon_size) || 60));
        const tbank = Math.max(24, Math.min(120, Number(style.tbank_icon_size) || icon));
        const font = Math.max(16, Math.min(64, Number(style.font_size) || 30));
        const autoSize = Math.max(20, Math.min(34, Math.round(tbank * 2 / 3)));
        const alif = Math.max(16, Math.min(120, Number(style.alif_icon_size) || autoSize));
        const dc = Math.max(16, Math.min(120, Number(style.dc_icon_size) || autoSize));
        const satellite = Math.max(alif, dc);
        const slot = Math.max(icon, tbank, alif + dc + 6);
        const drop = Math.ceil(tbank / 2 + satellite / 2 + 5);
        const lift = Math.round((drop + satellite / 2 - tbank / 2) / 2);
        const height = Math.ceil(Math.max(icon / 2, tbank / 2, font * .65, lift + tbank / 2, drop - lift + satellite / 2) * 2 + 12);
        for (const [key, value] of Object.entries({ icon, tbank, slot, font, satellite, lift, drop, height,
            'alif-size': alif, 'dc-size': dc })) {
            banner.style.setProperty('--kb-' + key, value + 'px');
        }
        if (!stage) {
            stage = document.createElement('span');
            stage.className = 'kaspi-banks-stage';
            stage.setAttribute('role', 'img');
            stage.innerHTML = '<span class="kb-mark kb-kaspi" aria-hidden="true"><img src="/static/KKS.F-9d710a31.png" alt=""></span>'
                + '<span class="kb-phone" aria-hidden="true"></span>'
                + '<span class="kb-mark kb-tbank" aria-hidden="true"><img src="/static/brands/tbank.png" alt=""></span>'
                + '<span class="kb-profile" aria-hidden="true"></span>'
                + '<span class="kb-satellite kb-alif" aria-hidden="true"><img src="/static/brands/alif.svg" alt=""></span>'
                + '<span class="kb-satellite kb-dc" aria-hidden="true"><img src="/static/brands/dc-next.png" alt=""></span>';
            banner.appendChild(stage);
            if (typeof ResizeObserver === 'function') {
                observer = new ResizeObserver(scheduleFit);
                observer.observe(stage);
            }
            document.fonts?.ready.then(scheduleFit);
        }
        stage.style.fontFamily = String(style.font_family || 'Oswald') + ', sans-serif';
        stage.style.color = String(style.text_color || '#ffffff');
        const phone = String(style.kaspi_number || '').trim() || 'Номер Kaspi';
        const profile = String(style.tbank_profile || '').trim() || 'на профиле';
        // Keep the animation objects alive when the widget polls or text changes.
        if (phoneValue !== phone) { stage.querySelector('.kb-phone').textContent = phone; phoneValue = phone; }
        if (profileValue !== profile) { stage.querySelector('.kb-profile').textContent = profile; profileValue = profile; }
        stage.setAttribute('aria-label', ['Kaspi', phone, 'Тинькофф', profile, 'Alif', 'DC'].join(', '));
        scheduleFit();
    }
    addEventListener('resize', scheduleFit);
    addEventListener('pagehide', dispose);
    window.KaspiBanks = { configure, dispose };
})();
