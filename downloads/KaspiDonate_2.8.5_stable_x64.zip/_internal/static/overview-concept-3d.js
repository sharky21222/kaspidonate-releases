import * as THREE from './three-r160.module.js';

const band = document.getElementById('scene-band');
const canvas = document.getElementById('scene-canvas');
const reducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)');

let renderer;
try {
  renderer = new THREE.WebGLRenderer({ canvas, antialias: true, alpha: true, powerPreference: 'low-power' });
} catch (error) {
  band.classList.add('scene-unavailable');
}

if (renderer) {
  renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.25));
  renderer.outputColorSpace = THREE.SRGBColorSpace;

  const scene = new THREE.Scene();
  const camera = new THREE.PerspectiveCamera(35, 1, 0.1, 100);
  camera.position.z = 7;

  const sculpture = new THREE.Group();
  scene.add(sculpture);

  const core = new THREE.Mesh(
    new THREE.IcosahedronGeometry(0.88, 1),
    new THREE.MeshStandardMaterial({ color: 0xdf544a, metalness: 0.5, roughness: 0.27, flatShading: true })
  );
  sculpture.add(core);

  const innerRing = new THREE.Mesh(
    new THREE.TorusGeometry(1.04, 0.025, 6, 72),
    new THREE.MeshBasicMaterial({ color: 0xc97898, transparent: true, opacity: 0.75 })
  );
  innerRing.rotation.x = 0.33;
  sculpture.add(innerRing);

  const progress = 0.59;
  const ringRest = new THREE.Mesh(
    new THREE.TorusGeometry(1.35, 0.09, 10, 72, Math.PI * 2 * (1 - progress)),
    new THREE.MeshStandardMaterial({ color: 0x71404e, metalness: 0.55, roughness: 0.36 })
  );
  ringRest.rotation.z = Math.PI * 2 * progress;
  sculpture.add(ringRest);

  const ringFill = new THREE.Mesh(
    new THREE.TorusGeometry(1.35, 0.09, 10, 72, Math.PI * 2 * progress),
    new THREE.MeshStandardMaterial({ color: 0xffae6f, emissive: 0x402013, metalness: 0.32, roughness: 0.27 })
  );
  sculpture.add(ringFill);

  const orbit = new THREE.Group();
  orbit.rotation.x = -0.22;
  scene.add(orbit);
  const markerGeometry = new THREE.IcosahedronGeometry(0.07, 0);
  const markerMaterial = new THREE.MeshBasicMaterial({ color: 0xffb9a6 });
  for (let index = 0; index < 3; index += 1) {
    const angle = index * Math.PI * 2 / 3;
    const marker = new THREE.Mesh(markerGeometry, markerMaterial);
    marker.position.set(Math.cos(angle) * 1.72, Math.sin(angle) * 1.72, 0.08);
    orbit.add(marker);
  }

  scene.add(new THREE.AmbientLight(0xe9aeb1, 1.4));
  const keyLight = new THREE.DirectionalLight(0xffe0ca, 2.7);
  keyLight.position.set(-2, 3, 5);
  scene.add(keyLight);
  const rimLight = new THREE.DirectionalLight(0xb99ce6, 1.8);
  rimLight.position.set(3, -2, 2);
  scene.add(rimLight);

  let visible = true;
  let timer = 0;
  let running = false;
  let targetX = 0;
  let targetY = 0;

  const render = () => renderer.render(scene, camera);
  const resize = () => {
    const width = Math.max(1, band.clientWidth);
    const height = Math.max(1, band.clientHeight);
    camera.aspect = width / height;
    camera.updateProjectionMatrix();
    renderer.setSize(width, height, false);
    const visibleWidth = 2 * Math.tan(THREE.MathUtils.degToRad(camera.fov) / 2) * camera.position.z * camera.aspect;
    const sculptureX = (width < 500 ? 0.32 : 0.28) * visibleWidth;
    sculpture.position.x = sculptureX;
    orbit.position.x = sculptureX;
    const scale = width < 500 ? 0.94 : 1.14;
    sculpture.scale.setScalar(scale);
    orbit.scale.setScalar(scale);
    render();
  };
  new ResizeObserver(resize).observe(band);
  resize();

  const stop = () => {
    running = false;
    clearTimeout(timer);
  };
  const frame = () => {
    if (!running) return;
    sculpture.rotation.y += 0.006;
    sculpture.rotation.x += (targetY - sculpture.rotation.x) * 0.055;
    sculpture.rotation.z += (targetX - sculpture.rotation.z) * 0.045;
    orbit.rotation.z += 0.003;
    render();
    timer = setTimeout(() => requestAnimationFrame(frame), 34);
  };
  const updateMotion = () => {
    if (document.hidden || !visible || reducedMotion.matches) {
      stop();
      render();
    } else if (!running) {
      running = true;
      requestAnimationFrame(frame);
    }
  };

  band.addEventListener('pointermove', (event) => {
    const bounds = band.getBoundingClientRect();
    targetX = ((event.clientX - bounds.left) / bounds.width - 0.5) * 0.34;
    targetY = ((event.clientY - bounds.top) / bounds.height - 0.5) * 0.25;
  });
  band.addEventListener('pointerleave', () => { targetX = 0; targetY = 0; });
  document.addEventListener('visibilitychange', updateMotion);
  reducedMotion.addEventListener('change', updateMotion);
  new IntersectionObserver((entries) => {
    visible = entries[0]?.isIntersecting ?? false;
    updateMotion();
  }, { threshold: 0.01 }).observe(band);
  updateMotion();
}
