(function (root) {
  'use strict';
  let active = null;
  const enabled = (config, donation) => config?.template === 'neon_pro' && donation?.alert_type !== 'voice_message';
  function stop() { if (active) active.finish('cancelled'); }
  function play({ host, donation = {}, comment = '', duration = 8000, config = {}, image = '' }) {
    stop();
    if (!host?.ownerDocument) return Promise.resolve('hidden');
    const doc = host.ownerDocument;
    host.classList.add('hidden');
    host.style.animation = 'none';
    const stage = doc.createElement('div');
    stage.className = 'neon-alert-stage';
    stage.dataset.phase = 'entering';
    stage.innerHTML = '<section class="neon-alert"><div class="neon-alert-panel"></div><div class="neon-alert-avatar"><b></b><img hidden alt=""></div><p class="neon-alert-caption">НОВЫЙ ДОНАТ</p><div class="neon-alert-heading"><strong class="neon-alert-sender"></strong><strong class="neon-alert-amount"></strong></div><p class="neon-alert-comment"></p></section>';
    const panel = stage.firstElementChild;
    panel.dataset.palette = ['blue','red','ice'].includes(config.neon?.palette) ? config.neon.palette : 'blue';
    const sender = stage.querySelector('.neon-alert-sender');
    sender.textContent = String(donation.sender || 'Аноним');
    stage.querySelector('.neon-alert-avatar b').textContent = Array.from(sender.textContent).slice(0,2).join('').toUpperCase();
    const amount = stage.querySelector('.neon-alert-amount');
    amount.textContent = (Number(donation.amount) || 0).toLocaleString('ru-RU') + ' ' + String(donation.currency || '₸');
    const message = stage.querySelector('.neon-alert-comment');
    message.textContent = String(comment || donation.comment || '');
    message.hidden = !message.textContent;
    const img = stage.querySelector('img');
    if (/^(https?:|data:image\/|\/)/i.test(image)) {
      img.src = image; img.hidden = false;
      img.onload = () => { stage.querySelector('.neon-alert-avatar b').hidden = true; };
      img.onerror = () => { img.hidden = true; };
    }
    doc.body.appendChild(stage);
    function fit() {
      // Measure the physical viewport, including the existing OBS body zoom.
      const zoom = Number.parseFloat(root.getComputedStyle(doc.body).zoom) || 1;
      const width = root.innerWidth / zoom;
      const height = root.innerHeight / zoom;
      sender.style.fontSize = '32px'; amount.style.fontSize = '32px';
      for (let size = 32; size > 14 && amount.scrollWidth > amount.clientWidth; size--) amount.style.fontSize = size + 'px';
      for (let size = 32; size > 20 && sender.scrollHeight > 76; size--) sender.style.fontSize = size + 'px';
      panel.style.setProperty('--neon-scale', String(Math.max(.03, Math.min(1,(width - 24)/720,(height - 24)/panel.offsetHeight))));
    }
    fit();
    root.addEventListener('resize', fit);
    return new Promise(resolve => {
      let enterTimer, leaveTimer, endTimer;
      const finish = reason => {
        if (active?.stage !== stage) return;
        clearTimeout(enterTimer); clearTimeout(leaveTimer); clearTimeout(endTimer);
        root.removeEventListener('resize', fit);
        img.onload = img.onerror = null;
        img.removeAttribute('src'); stage.remove(); active = null; resolve(reason);
      };
      active = { stage, finish };
      enterTimer = setTimeout(() => { stage.dataset.phase = 'visible'; }, 1000);
      const ms = Math.max(3000, Math.min(30000, Number(duration) || 8000));
      leaveTimer = setTimeout(() => stage.classList.add('is-leaving'), ms - 350);
      endTimer = setTimeout(() => finish('ended'), ms);
    });
  }
  root.KaspiNeonAlert = Object.freeze({ enabled, play, stop });
})(window);
