(function () {
    'use strict';
    const host = document.getElementById('youtubePlayerContainer');
    const sourceId = 'music-' + Date.now().toString(36) + '-' + Math.random().toString(36).slice(2, 10);
    const preview = new URLSearchParams(location.search).get('mute') === '1';
    window.__KASPI_PREVIEW__ = preview;
    let order = null, player = null, volume = .5, remaining = 0, position = 0;
    let phase = 'idle', error = '', sourceVisible = true, closed = false, busy = false;
    let paused = false, started = false, finishing = false, generation = 0;
    let commandId = '', heartbeatAt = 0, sampleAt = performance.now(), startedAt = 0;
    let lastPosition = 0, embedProgressAt = 0, embedCleanup = null;
    const timers = new Set();
    const later = (fn, ms) => { const id = setTimeout(() => { timers.delete(id); fn(); }, ms); timers.add(id); return id; };
    const frameState = () => ({view: true, active: !!order, sender: order?.sender || '',
        playerState: player?.getPlayerState?.() ?? -1, paused, volume});
    const progress = () => ({position, remainingMs: Math.max(0, remaining)});
    async function request(url, body) {
        const controller = new AbortController();
        const id = setTimeout(() => controller.abort(), 7000);
        try {
            const response = await fetch(url, {cache: 'no-store', signal: controller.signal,
                ...(body ? {method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify(body)} : {})});
            if (!response.ok) throw new Error('HTTP ' + response.status);
            return await response.json();
        } finally {clearTimeout(id);}
    }
    const report = data => request('/api/youtube_music_orders', data);
    function payload(action, reason = '') {
        return {action, requestId: order.requestId, claimId: order.claimId, playbackTracked: true, reason, ...progress()};
    }
    function releaseMedia() {
        if (embedCleanup) { embedCleanup(); embedCleanup = null; }
        player?.destroy?.(); player = null;
        host.replaceChildren();
    }
    async function finish(action, reason) {
        if (!order || finishing) return;
        finishing = true;
        phase = action === 'failed' ? 'error' : 'finishing';
        if (action === 'failed') error = String(reason || 'Playback failed');
        const token = generation, data = payload(action, reason);
        releaseMedia();
        let accepted = false;
        for (let attempt = 0; attempt < 3 && !closed && token === generation; ++attempt) {
            try {
                const result = await report(data);
                if (result.status !== 'ok' && result.status !== 'not_found') throw new Error('Order report rejected');
                accepted = true; break;
            } catch (err) {
                error = 'Не удалось подтвердить заказ: ' + err.message;
                await new Promise(resolve => later(resolve, 800 * (attempt + 1)));
            }
        }
        if (closed || token !== generation) return;
        if (!accepted) {
            finishing = false;
            later(() => finish(action, reason), 3000);
            return;
        }
        ++generation;
        order = null; remaining = position = 0; started = finishing = paused = false;
        phase = 'idle';
        window.KaspiYoutubeAudioFrame.sync();
        later(poll, 0);
    }
    async function playing(token) {
        if (closed || token !== generation || !order || finishing || paused) return;
        phase = 'playing'; error = '';
        if (started) return;
        started = true;
        try {
            const result = await report(payload('started'));
            if (token !== generation) return;
            if (result.status === 'not_found') abandon();
            else if (result.status !== 'ok') throw new Error('Order start rejected');
        } catch (err) { if (token === generation) {started = false; error = err.message;} }
    }
    function abandon() {
        ++generation; releaseMedia(); order = null; finishing = started = false;
        phase = 'idle';
    }
    function embed(token, resumeAt, isPaused) {
        if (closed || token !== generation || !order || finishing) return;
        releaseMedia(); paused = isPaused; phase = paused ? 'paused' : 'loading';
        let state = paused ? 2 : -1, current = resumeAt, duration = 0;
        const iframe = document.createElement('iframe');
        const url = new URL('https://www.youtube.com/embed/' + order.videoId);
        for (const [k, v] of Object.entries({autoplay: paused ? 0 : 1, enablejsapi: 1, origin: location.origin,
            start: Math.floor(resumeAt), playsinline: 1, controls: 0, mute: volume <= 0 ? 1 : 0, rel: 0})) url.searchParams.set(k, v);
        iframe.allow = 'autoplay; encrypted-media'; iframe.referrerPolicy = 'strict-origin-when-cross-origin';
        iframe.src = url.href;
        const send = (func, args = []) => iframe.contentWindow?.postMessage(JSON.stringify({event: 'command', func, args}), 'https://www.youtube.com');
        const applyVolume = () => {send(volume > 0 ? 'unMute' : 'mute'); send('setVolume', [volume * 100]);};
        const listen = () => iframe.contentWindow?.postMessage(JSON.stringify({event: 'listening', id: sourceId, channel: 'widget'}), 'https://www.youtube.com');
        function message(event) {
            if (token !== generation || event.source !== iframe.contentWindow || event.origin !== 'https://www.youtube.com') return;
            let data = event.data;
            if (typeof data === 'string') {try {data = JSON.parse(data);} catch (_) {return;}}
            if (!data || typeof data !== 'object') return;
            if (data.event === 'onReady' || data.event === 'initialDelivery') {
                applyVolume(); send('setPlaybackQuality', ['small']); if (!paused) send('playVideo');
            }
            if (data.event === 'infoDelivery') {
                if (Number.isFinite(Number(data.info?.currentTime))) current = Number(data.info.currentTime);
                if (Number.isFinite(Number(data.info?.duration))) duration = Number(data.info.duration);
            }
            const nextState = data.event === 'onStateChange' ? data.info : data.info?.playerState;
            if (Number.isInteger(nextState)) {
                state = nextState;
                if (state === 1) {applyVolume(); playing(token);}
                if (state === 0 && started) finish('completed', 'ended');
            }
            if (data.event === 'onError') finish('failed', 'YouTube отклонил ролик (код ' + data.info + ')');
        }
        addEventListener('message', message);
        iframe.addEventListener('load', listen);
        host.replaceChildren(iframe);
        embedCleanup = () => {removeEventListener('message', message); iframe.remove();};
        embedProgressAt = performance.now();
        player = {getPlayerState: () => state, getCurrentTime: () => current, getDuration: () => duration,
            playVideo: () => {paused = false; send('playVideo');}, pauseVideo: () => {paused = true; send('pauseVideo');},
            setVolume: applyVolume, destroy: () => {send('stopVideo'); iframe.remove();}, listen};
    }
    function startMedia() {
        if (!order || player || !sourceVisible || closed) return;
        const token = generation;
        phase = paused ? 'paused' : 'loading'; startedAt = sampleAt = performance.now();
        lastPosition = position;
        try {
            player = window.KaspiYoutubeAudioPlayer.create({host, videoId: order.videoId, requestId: order.requestId,
                startSeconds: position, paused, volume: () => volume,
                onPlaying: () => playing(token),
                onEnded: () => {if (token === generation) finish('completed', 'ended');},
                onError: reason => {if (token === generation) finish('failed', reason);},
                onFallback: (reason, resumeAt, wasPaused) => embed(token, resumeAt, wasPaused)});
        } catch (err) { finish('failed', 'Не удалось создать плеер: ' + err.message); }
    }
    function start(next) {
        if (!next?.claimId || !/^[A-Za-z0-9_-]{11}$/.test(next.videoId || '')) return;
        ++generation; order = next; started = finishing = paused = false; error = '';
        const budget = Number(next.remainingDurationMs ?? next.durationMs ?? 180000);
        remaining = Math.max(0, Number.isFinite(budget) ? budget : 180000);
        position = Math.max(0, Number(next.startSeconds) || 0);
        if (!remaining) {finish('completed', 'duration_limit'); return;}
        startMedia();
        window.KaspiYoutubeAudioFrame.sync();
    }
    function control(command) {
        if (!order || !command?.id || command.id === commandId || command.requestId !== order.requestId
            || (command.claimId && command.claimId !== order.claimId)) return;
        commandId = command.id;
        if (command.action === 'stop' || command.action === 'next') finish('stopped', command.action === 'next' ? 'manual_next' : 'manual_stop');
        if (command.action === 'pause') {paused = true; phase = 'paused'; player?.pauseVideo?.();}
        if (command.action === 'resume') {paused = false; phase = 'loading'; startedAt = performance.now(); player?.playVideo?.();}
    }
    async function poll() {
        if (busy || closed || preview) return;
        busy = true;
        try {
            const state = await request('/api/youtube_playback', {sourceId, phase, error: error.slice(0, 240),
                requestId: order?.requestId || '', ...progress(), visible: sourceVisible});
            if (closed) return;
            volume = Math.max(0, Math.min(1, Number(state.volume) || 0));
            player?.setVolume?.(volume * 100);
            if (order) {
                if (!finishing && (state.reserved?.requestId !== order.requestId || state.reserved?.claimId !== order.claimId)) {abandon(); return;}
                control(state.control);
                if (!finishing && Date.now() - heartbeatAt >= 10000) {
                    heartbeatAt = Date.now();
                    const result = await report(payload('heartbeat'));
                    if (result.status === 'not_found') abandon();
                }
            } else if (sourceVisible && state.pending > 0) {
                const result = await report({action: 'claim'});
                if (closed) return;
                if (result.order) start(result.order);
            }
        } catch (err) {error = 'Связь с очередью: ' + err.message;}
        finally {busy = false;}
    }
    function tick() {
        const now = performance.now(), elapsed = now - sampleAt;
        sampleAt = now;
        if (!order || finishing || !sourceVisible || !player) return;
        const current = Math.max(0, Number(player.getCurrentTime?.()) || 0);
        const moved = current - lastPosition;
        if (!paused && player.getPlayerState?.() === 1 && moved > 0 && moved * 1000 <= elapsed + 2000) {
            remaining = Math.max(0, remaining - Math.min(moved * 1000, elapsed + 500));
            embedProgressAt = now; phase = 'playing'; playing(generation);
        }
        lastPosition = position = current;
        if (!paused && remaining <= 0) {finish('completed', 'duration_limit'); return;}
        if (!paused && player.listen) {
            if (now - startedAt > 35000 && !started) {finish('failed', 'Встроенный YouTube не начал воспроизведение'); return;}
            if (started && now - embedProgressAt > 45000) {finish('failed', 'Встроенный YouTube перестал отдавать звук'); return;}
            if (Math.floor(now / 2000) !== Math.floor((now - elapsed) / 2000)) player.listen();
        }
    }
    window.KaspiYoutubeAudioFrame.configure({youtube_template: 'audio_frame'}, frameState);
    const pollTimer = setInterval(poll, 2000), tickTimer = setInterval(tick, 250);
    addEventListener('obsSourceVisibleChanged', event => {
        sourceVisible = event.detail?.visible !== false;
        if (!sourceVisible) {position = Number(player?.getCurrentTime?.()) || position; releaseMedia(); phase = 'suspended';}
        else {startMedia(); poll();}
    });
    addEventListener('pagehide', () => {
        closed = true; clearInterval(pollTimer); clearInterval(tickTimer);
        if (order) navigator.sendBeacon('/api/youtube_music_orders', new Blob([JSON.stringify(payload('heartbeat'))], {type: 'application/json'}));
        ++generation; releaseMedia(); timers.forEach(clearTimeout); timers.clear();
    });
    poll();
})();
