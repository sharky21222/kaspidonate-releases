(() => {
  const clock = document.querySelector('[data-clock]');
  const date = document.querySelector('[data-date]');
  const updateTime = () => {
    const now = new Date();
    clock.textContent = new Intl.DateTimeFormat('ru-RU', { hour: '2-digit', minute: '2-digit' }).format(now);
    date.textContent = new Intl.DateTimeFormat('ru-RU', { day: 'numeric', month: 'long' }).format(now);
  };
  updateTime();
  setInterval(updateTime, 60_000);

  const alertVolume = document.querySelector('#alert-volume');
  const musicVolume = document.querySelector('#music-volume');
  const note = document.querySelector('[data-mixer-note]');
  const updateMixer = () => {
    for (const [name, slider] of [['alert', alertVolume], ['music', musicVolume]]) {
      document.querySelector(`[data-value="${name}"]`).textContent = `${slider.value}%`;
      slider.style.setProperty('--volume', `${slider.value}%`);
    }
    const difference = Number(musicVolume.value) - Number(alertVolume.value);
    note.textContent = difference === 0
      ? 'Громкость алерта и музыки одинакова'
      : `${difference > 0 ? 'Музыка громче алерта' : 'Алерт громче музыки'} на ${Math.abs(difference)} %`;
  };
  alertVolume.addEventListener('input', updateMixer);
  musicVolume.addEventListener('input', updateMixer);
  updateMixer();

  document.querySelectorAll('.rail-link').forEach((button) => {
    button.addEventListener('click', () => {
      document.querySelectorAll('.rail-link').forEach((item) => {
        item.classList.toggle('is-active', item === button);
        if (item === button) item.setAttribute('aria-current', 'page');
        else item.removeAttribute('aria-current');
      });
      document.getElementById(button.dataset.scroll)?.scrollIntoView({ block: 'start', behavior: 'smooth' });
    });
  });
})();
