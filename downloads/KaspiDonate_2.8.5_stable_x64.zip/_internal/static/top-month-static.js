(function () {
    'use strict';

    const runtime = window.KaspiWidgetRuntime;
    const strip = document.getElementById('monthStaticStrip');
    const slots = Array.from(strip.querySelectorAll('.month-static-slot'));
    let request = null;
    let switchingTemplate = false;
    let lastRowsKey = '';

    function fitStrip() {
        const width = Math.max(1, document.documentElement.clientWidth || window.innerWidth);
        const scale = Math.min(1, width / 1080);
        const transform = scale < 1 ? 'scale(' + scale + ')' : '';
        if (strip.style.transform !== transform) strip.style.transform = transform;
    }

    function fitAmounts() {
        slots.forEach(function (slot) {
            const amount = slot.querySelector('.month-static-amount');
            amount.style.fontSize = '20px';
            if (amount.clientWidth > 0 && amount.scrollWidth > amount.clientWidth) {
                amount.style.fontSize = Math.max(12, Math.floor(20 * amount.clientWidth / amount.scrollWidth)) + 'px';
            }
        });
    }

    function updateRows(data) {
        const donors = (Array.isArray(data) ? data : []).slice(0, 5);
        const key = JSON.stringify(donors.map(function (item) {
            return [item.sender, Math.round(Number(item.amount) || 0), item.currency || '₸'];
        }));
        if (key === lastRowsKey) return;
        lastRowsKey = key;

        slots.forEach(function (slot, index) {
            const rank = 5 - index;
            const donor = donors[rank - 1];
            const name = donor ? String(donor.sender || 'Аноним') : '—';
            const amount = donor
                ? Math.round(Number(donor.amount) || 0).toLocaleString('ru-RU') + ' ' + (donor.currency || '₸')
                : '';
            slot.querySelector('.month-static-name').textContent = name;
            slot.querySelector('.month-static-amount').textContent = amount;
            slot.classList.toggle('is-empty', !donor);
            slot.setAttribute('aria-label', donor ? rank + ' место: ' + name + ', ' + amount : rank + ' место свободно');
            slot.title = donor ? name + ' — ' + amount : '';
        });
        fitAmounts();
    }

    async function loadData() {
        if (request || switchingTemplate || !runtime.active(['top'])) return;
        const controller = new AbortController();
        request = controller;
        const timeout = setTimeout(function () { controller.abort(); }, 6000);
        try {
            const response = await fetch('/api/top_month_data', {
                cache: 'no-store', signal: controller.signal,
            });
            if (!response.ok) return;
            const payload = await response.json();
            if (!runtime.active(['top']) || payload.status !== 'ok') return;
            if (payload.config?.template !== 'horizontal_static') {
                switchingTemplate = true;
                location.reload();
                return;
            }
            updateRows(payload.data);
        } catch (_) {
            // Keep the current strip visible if a poll fails.
        } finally {
            clearTimeout(timeout);
            if (request === controller) request = null;
        }
    }

    window.KaspiTopMonthStatic = { refresh: loadData };
    fitStrip();
    runtime.every(loadData, 4000, ['top'], true);
    runtime.subscribe(function (active) {
        if (active) loadData();
        else if (request) {
            request.abort();
            request = null;
        }
    });
    window.addEventListener('resize', fitStrip);
    if (document.fonts && document.fonts.ready) document.fonts.ready.then(fitAmounts).catch(function () {});
})();
