(function (root) {
    'use strict';
    const fitted = new WeakMap();
    const measure = document.createElement('canvas').getContext('2d');
    let frame = 0;

    function fit(element, maxSize, width, height) {
        if (!element || width <= 0 || height <= 0 || getComputedStyle(element).display === 'none') return;
        element.style.removeProperty('--blood-font-size');
        let low = 1;
        let high = Math.min(maxSize, parseFloat(getComputedStyle(element).fontSize) || maxSize);
        // Changes happen only on data/config/size updates, never on an idle timer.
        for (let step = 0; step < 10; step++) {
            const size = (low + high) / 2;
            element.style.setProperty('--blood-font-size', size.toFixed(2) + 'px');
            const style = getComputedStyle(element);
            let fits;
            if (style.whiteSpace === 'nowrap' && measure) {
                measure.font = `${style.fontWeight} ${style.fontSize} ${style.fontFamily}`;
                const text = style.textTransform === 'uppercase' ? element.textContent.toLocaleUpperCase('ru-RU') : element.textContent;
                fits = measure.measureText(text).width <= width && (parseFloat(style.lineHeight) || size) <= height;
            } else {
                fits = element.scrollWidth <= width + 1 && element.scrollHeight <= height + 1;
            }
            if (fits) low = size;
            else high = size;
        }
        element.style.setProperty('--blood-font-size', Math.max(1, low - .1).toFixed(2) + 'px');
    }

    function prepareGoal(container, template) {
        if (!container) return;
        let track = container.querySelector('.blood-goal-track');
        const progress = container.querySelector('#goalProgress');
        if (template !== 'bloodpubg') {
            if (track) { container.insertBefore(progress, track); track.remove(); }
            delete container.dataset.bloodSize;
            container.querySelectorAll('#goalText, #goalStart, #goalTarget').forEach(el => el.style.removeProperty('--blood-font-size'));
            fitted.delete(container);
            return;
        }
        if (!track && progress) {
            track = document.createElement('div');
            track.className = 'blood-goal-track';
            container.insertBefore(track, progress);
            track.appendChild(progress);
        }
        container.dataset.bloodSize = container.clientHeight < 24 ? 'thin' : 'regular';
    }

    function fitGoal(force) {
        const goal = document.querySelector('.donation-goal.goal-bloodpubg');
        if (!goal) return;
        goal.dataset.bloodSize = goal.clientHeight < 24 ? 'thin' : 'regular';
        const text = [...goal.querySelectorAll('#goalText, #goalStart, #goalTarget')];
        const key = [goal.clientWidth, goal.clientHeight, ...text.map(el => [el.textContent, el.style.fontSize, el.style.display])].join('|');
        if (!force && fitted.get(goal) === key) return;
        text.forEach(el => fit(el, 72, el.clientWidth, el.clientHeight));
        fitted.set(goal, key);
    }

    function fitTop(force) {
        const top = document.querySelector('#leftColumn.template-bloodpubg');
        if (!top) return;
        const title = top.querySelector('.top-donations-title');
        const rows = [...top.querySelectorAll('.top-donation-item')];
        const key = [top.clientWidth, title?.textContent, ...rows.map(row => row.textContent)].join('|');
        if (!force && fitted.get(top) === key) return;
        if (title) fit(title, 40, title.clientWidth - 79, title.clientHeight);
        rows.forEach(row => {
            if (getComputedStyle(row).display === 'none') return;
            const header = row.querySelector('.top-donation-header');
            const amount = row.querySelector('.top-donation-amount');
            const name = row.querySelector('.sender-name');
            const sender = row.querySelector('.top-donation-sender');
            if (!header || !amount || !name || !sender) return;
            header.style.setProperty('--blood-amount-width', (Math.max(30, header.clientWidth - 54) * .51).toFixed(2) + 'px');
            fit(amount, 40, Math.max(1, amount.clientWidth - 8), header.clientHeight * .85);
            fit(name, 40, sender.clientWidth, header.clientHeight * .85);
        });
        fitted.set(top, key);
    }

    function refresh(force) {
        cancelAnimationFrame(frame);
        frame = requestAnimationFrame(() => { frame = 0; fitGoal(force); fitTop(force); });
    }
    root.KaspiBloodPubg = { prepareGoal, refresh };
    root.addEventListener('resize', () => refresh(true), { passive: true });
    document.fonts?.ready.then(() => refresh(true)).catch(() => {});
})(window);
