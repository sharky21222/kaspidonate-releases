(function () {
    'use strict';
    let banner = null, stage = null, observer = null, fitJob = 0;
    function fit() {
        fitJob = 0;
        if (!stage?.isConnected) return;
        let zoom = 1;
        for (let node = banner; node; node = node.parentElement) {
            const value = parseFloat(getComputedStyle(node).zoom);
            if (Number.isFinite(value) && value > 0) zoom *= value;
        }
        const width = stage.offsetWidth + 10;
        const availableHeight = Math.max(16, innerHeight - banner.getBoundingClientRect().top - 12);
        banner.style.setProperty('--profile-fit', Math.max(.02, Math.min(1.6, (innerWidth - 24) / (width * zoom),
            availableHeight / ((stage.offsetHeight + 10) * zoom))));
    }
    function scheduleFit() {
        if (!fitJob && stage) fitJob = requestAnimationFrame(fit);
    }
    function dispose() {
        observer?.disconnect(); observer = null;
        cancelAnimationFrame(fitJob); fitJob = 0;
        stage?.remove(); stage = null;
        banner?.style.removeProperty('--profile-fit');
        banner = null;
    }
    function configure(style, host = document.querySelector('.kaspi-banner')) {
        if (style?.template !== 'profile_banks' || !host) {dispose(); return;}
        if (banner !== host) dispose();
        banner = host;
        const size = Math.max(24, Math.min(96, Number(style.icon_size) || 60));
        banner.style.setProperty('--profile-icon-size', size + 'px');
        for (const bank of ['tbank', 'alif', 'dc']) {
            const bankSize = Math.max(bank === 'tbank' ? 24 : 16, Math.min(120, Number(style[bank + '_icon_size']) || size));
            banner.style.setProperty('--profile-' + bank + '-size', bankSize + 'px');
        }
        if (!stage) {
            stage = document.createElement('span');
            stage.className = 'kaspi-profile-stage';
            stage.setAttribute('role', 'img');
            stage.setAttribute('aria-label', 'DC, Alif, Т-Банк — на профиле');
            stage.innerHTML = '<span class="profile-bank profile-bank-dc"><img src="/static/brands/dc-next.png" alt="" width="60" height="60"></span>'
                + '<span class="profile-bank profile-bank-alif"><img src="/static/brands/alif.svg" alt="" width="60" height="60"></span>'
                + '<span class="profile-bank profile-bank-tbank"><img src="/static/brands/tbank.png" alt="" width="60" height="60"></span>'
                + '<span class="profile-bank-caption">на профиле</span>';
            banner.appendChild(stage);
            if (typeof ResizeObserver === 'function') {
                observer = new ResizeObserver(scheduleFit);
                observer.observe(stage);
            }
            document.fonts?.ready.then(scheduleFit);
        }
        scheduleFit();
    }
    addEventListener('resize', scheduleFit);
    addEventListener('pagehide', dispose);
    window.KaspiProfileBanks = {configure, dispose};
})();
