(function () {
    'use strict';
    let inFlight = false;
    let pending = false;
    let queued = 0;
    let lastKey = '';
    let events = null;
    let disposed = false;
    let controller = null;
    let previousValues = null;
    let finishArtwork = null;
    const animations = new Set();
    const reducedMotion = window.matchMedia?.('(prefers-reduced-motion: reduce)');

    function stopAnimations() {
        animations.forEach(function (animation) { animation.cancel(); });
        animations.clear();
    }

    function animate(el, frames, options) {
        if (typeof el.animate !== 'function') return;
        const animation = el.animate(frames, options);
        animations.add(animation);
        animation.oncancel = function () { animations.delete(animation); };
        animation.onfinish = function () {
            animations.delete(animation);
            animation.cancel();
        };
    }

    function writeNumber(el, value, delay, motion) {
        if (!motion || typeof el.animate !== 'function' || !/^\d+(?:\.\d+)?$/.test(value)) {
            if (el.textContent !== value) el.textContent = value;
            return;
        }
        // Lay out the complete number once; only its prepainted glyphs move.
        const digits = Array.from(value, function (character) {
            const digit = document.createElement('span');
            digit.className = 'pubg-digit';
            digit.textContent = character;
            return digit;
        });
        el.replaceChildren(...digits);
        const step = Math.min(70, 420 / Math.max(1, digits.length - 1));
        digits.forEach(function (digit, index) {
            animate(digit, [
                { opacity: 0, transform: 'translateY(.18em)' },
                { opacity: 1, transform: 'translateY(0)' }
            ], { duration: 280, delay: delay + index * step,
                easing: 'cubic-bezier(.22, 1, .36, 1)', fill: 'backwards' });
        });
    }

    function waitForArtwork(images) {
        const decodes = Array.from(images).filter(function (img) { return typeof img.decode === 'function'; });
        if (!decodes.length) return Promise.resolve();
        return new Promise(function (resolve) {
            let settled = false;
            const done = function () {
                if (settled) return;
                settled = true;
                clearTimeout(timeout);
                finishArtwork = null;
                resolve();
            };
            const timeout = setTimeout(done, 1200);
            finishArtwork = done;
            Promise.all(decodes.map(function (img) {
                return Promise.resolve().then(function () { return img.decode(); }).catch(function () {});
            })).then(done);
        });
    }

    async function paint(data) {
        const template = ['m24', 'pan', 'beryl', 'pirate'].includes(data.widget_template)
            ? data.widget_template : 'm24';
        const values = { template, kd: Number(data.stats?.kd ?? 0).toFixed(2),
            kills: String(data.stats?.kills ?? '--'), nickname: data.nickname || 'PUBG PLAYER',
            showKd: data.show_kd ? '1' : '0' };
        const key = JSON.stringify(values);
        if (key === lastKey) return;
        const scene = document.querySelector('.scene-' + template);
        if (!scene) return;
        const entering = !previousValues || previousValues.template !== template;
        // Hidden skins must not decode their large artwork in every Browser Source.
        const artwork = scene.querySelectorAll('img[data-src]');
        artwork.forEach(function (img) {
            if (!img.hasAttribute('src')) {
                img.decoding = 'async';
                img.src = img.dataset.src;
            }
        });
        if (entering) await waitForArtwork(artwork);
        if (disposed) return;

        const changed = entering || previousValues.kills !== values.kills
            || previousValues.nickname !== values.nickname
            || (values.showKd === '1' && (previousValues.kd !== values.kd || previousValues.showKd !== '1'));
        const motion = changed && !document.hidden && !reducedMotion?.matches;
        if (changed) stopAnimations();
        document.body.dataset.template = template;
        document.body.dataset.showKd = values.showKd;
        scene.querySelectorAll('[data-nickname]').forEach(function (el) {
            if (el.textContent !== values.nickname) el.textContent = values.nickname;
        });
        [['kills', values.kills], ['kd', values.kd]].forEach(function (entry) {
            scene.querySelectorAll('[data-' + entry[0] + ']').forEach(function (el) {
                writeNumber(el, entry[1], entering ? 240 : 160,
                    motion && (entry[0] === 'kills' || values.showKd === '1'));
            });
        });
        if (motion) {
            const frames = entering ? [
                { opacity: 0, transform: 'translateY(6px)' },
                { opacity: 1, transform: 'translateY(0)' }
            ] : [
                { opacity: 1, transform: 'translateY(0)', offset: 0, easing: 'ease-in-out' },
                { opacity: .32, transform: 'translateY(2px)', offset: .18, easing: 'cubic-bezier(.22, 1, .36, 1)' },
                { opacity: 1, transform: 'translateY(0)', offset: 1 }
            ];
            animate(scene, frames, { duration: entering ? 900 : 760,
                easing: entering ? 'cubic-bezier(.22, 1, .36, 1)' : 'linear', fill: 'backwards' });
        }
        lastKey = key;
        previousValues = values;
    }

    function queueLive() {
        if (disposed || queued) return;
        queued = setTimeout(function () { queued = 0; load('/api/pubg/live'); }, 250);
    }

    async function load(url) {
        if (disposed) return;
        if (inFlight) { pending = true; return; }
        inFlight = true;
        controller = new AbortController();
        const timeout = setTimeout(function () { controller?.abort(); }, 6000);
        try {
            const response = await fetch(url, { cache: 'no-store', signal: controller.signal });
            if (!response.ok) throw new Error('HTTP ' + response.status);
            const data = await response.json();
            if (!disposed) await paint(data);
        } catch (_) {
            // Preserve the last known score on a timeout or a backend restart.
            if (!disposed && !lastKey) await paint({});
        } finally {
            clearTimeout(timeout);
            controller = null;
            inFlight = false;
            if (pending) { pending = false; queueLive(); }
        }
    }

    load('/api/pubg');
    const poll = setInterval(function () { load('/api/pubg'); }, 30000);
    try { events = new EventSource('/api/events'); events.addEventListener('update', queueLive); } catch (_) {}
    document.addEventListener('visibilitychange', function () {
        if (document.hidden) stopAnimations();
    });
    reducedMotion?.addEventListener?.('change', function () {
        if (reducedMotion.matches) stopAnimations();
    });
    window.addEventListener('pagehide', function (event) {
        stopAnimations();
        if (event.persisted) return;
        disposed = true;
        finishArtwork?.();
        clearInterval(poll);
        clearTimeout(queued);
        controller?.abort();
        events?.close();
    });
})();
