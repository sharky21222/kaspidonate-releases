(function () {
    'use strict';
    if (window.KaspiWidgetPerformance) return;

    const root = document.documentElement;
    const force = new URLSearchParams(location.search).get('perf');
    let frame = 0;
    let start = null;
    let previous = null;
    let frames = 0;
    let low = 0;
    let healthy = 0;
    let stopped = false;
    let templateObserver = null;
    const widgetView = window.KaspiWidgetRuntime?.view();
    let leanTemplate = false;

    function isLeanTemplate(widget) {
        return widgetView === 'goal' ? (widget.classList.contains('goal-segments') || widget.classList.contains('goal-bloodpubg'))
            : widgetView === 'donatel' ? widget.classList.contains('kaspi-template-transparent')
            : widgetView === 'top' && widget.classList.contains('template-redpro');
    }

    function setLite(lite) {
        root.classList.toggle('perf-lite', lite);
        root.dataset.widgetMotionMode = lite ? 'balanced' : 'full';
        low = 0;
        healthy = 0;
    }

    function resetSample() {
        start = null;
        previous = null;
        frames = 0;
        low = 0;
        healthy = 0;
    }

    function sample(now) {
        const hidden = document.hidden || document.body?.classList.contains('youtube-active');
        // A hidden source, sleep or a restored window is not a rendering benchmark.
        if (hidden || (previous !== null && now - previous >= 1000)) {
            resetSample();
            return;
        }
        previous = now;
        if (start === null) { start = now; return; }
        frames++;
        const elapsed = now - start;
        if (elapsed < 2000) return;

        const fps = frames * 1000 / elapsed;
        window.__widgetFps = Math.round(fps);
        root.dataset.widgetFps = String(Math.round(fps));
        start = now;
        frames = 0;
        if (force === 'lite' || force === 'full') return;

        if (root.classList.contains('perf-lite')) {
            healthy = fps >= 45 ? healthy + 1 : 0;
            if (healthy >= 10) setLite(false);
        } else {
            low = fps < 28 ? low + 1 : 0;
            if (low >= 2) setLite(true);
        }
    }

    function animate(now) {
        if (stopped || leanTemplate ||
            (window.KaspiWidgetRuntime && !window.KaspiWidgetRuntime.active(['top', 'goal', 'donatel', 'month']))) {
            frame = 0;
            return;
        }
        sample(now);
        frame = requestAnimationFrame(animate);
    }

    setLite(force === 'lite' || (force !== 'full' && root.classList.contains('perf-lite')));
    window.KaspiWidgetPerformance = { reset: resetSample };
    document.addEventListener('visibilitychange', resetSample);
    window.addEventListener('pageshow', resetSample);
    window.addEventListener('pagehide', function (event) {
        if (event.persisted) { resetSample(); return; }
        stopped = true;
        cancelAnimationFrame(frame);
        templateObserver?.disconnect();
    });
    function syncRuntime() {
        cancelAnimationFrame(frame); frame = 0; resetSample();
        if (!leanTemplate &&
            (!window.KaspiWidgetRuntime || window.KaspiWidgetRuntime.active(['top', 'goal', 'donatel', 'month']))) {
            frame = requestAnimationFrame(animate);
        }
    }
    function watchLeanTemplate() {
        const selector = widgetView === 'goal' ? '.donation-goal'
            : widgetView === 'donatel' ? '.kaspi-banner' : widgetView === 'top' ? '.left-column' : null;
        if (!selector) return;
        const widget = document.querySelector(selector);
        if (!widget) {
            document.addEventListener('DOMContentLoaded', watchLeanTemplate, { once: true });
            return;
        }
        leanTemplate = isLeanTemplate(widget);
        templateObserver = new MutationObserver(function () {
            const isLean = isLeanTemplate(widget);
            if (isLean === leanTemplate) return;
            leanTemplate = isLean;
            syncRuntime();
        });
        templateObserver.observe(widget, { attributes: true, attributeFilter: ['class'] });
        syncRuntime();
    }
    window.KaspiWidgetRuntime?.subscribe(syncRuntime);
    syncRuntime();
    watchLeanTemplate();
})();
