(function () {
    'use strict';
    if (window.KaspiWidgetContinuity) return;

    const names = new Set(['kaspiBankPrimary', 'kaspiBankSecondary', 'dualFadeKaspi',
        'dualFadeTbank', 'goalSegmentsFlow', 'goalShine', 'goalFillFlow', 'goalWaveBob',
        'heartbeat', 'scrollText', 'goalTextShift']);
    const samples = new Map();
    const reduced = window.matchMedia?.('(prefers-reduced-motion: reduce)');
    let timer = 0;
    let suspended = false;
    let disposed = false;
    let previousTick = 0;

    function selected(view) {
        if (window.KaspiWidgetRuntime) return window.KaspiWidgetRuntime.shows(view);
        const query = new URLSearchParams(location.search);
        if (query.has('goal_only')) return view === 'goal';
        if (query.has('kaspi_only')) return view === 'donatel';
        if (query.has('alert_only')) return false;
        const hash = location.hash.slice(1).toLowerCase();
        return !hash || hash === view;
    }

    function tick() {
        if (disposed || suspended) return;
        const now = performance.now();
        const asleep = previousTick && now - previousTick > 8000;
        previousTick = now;
        if (asleep || document.hidden || reduced?.matches ||
            document.body.classList.contains('youtube-active') ||
            document.body.classList.contains('animations-resetting')) {
            samples.clear();
            return;
        }
        const seen = new Set();
        [['donatel', '.kaspi-banner'], ['goal', '.goal-wrapper']].forEach(function (entry) {
            if (!selected(entry[0])) return;
            const root = document.querySelector(entry[1]);
            if (!root?.getAnimations) return;
            root.getAnimations({ subtree: true }).forEach(function (animation) {
                if (!names.has(animation.animationName) || animation.pending || animation.playbackRate === 0) return;
                const effect = animation.effect;
                const target = effect?.target;
                const time = animation.currentTime;
                if (!target?.isConnected ||
                    typeof time !== 'number' || !Number.isFinite(time) ||
                    effect.getTiming().iterations !== Infinity ||
                    !['running', 'paused'].includes(animation.playState)) return;
                seen.add(animation);
                let sample = samples.get(animation);
                if (!sample || Math.abs(time - sample.time) > .5) {
                    samples.set(animation, { time: time, since: now, retryAt: 0, retries: 0 });
                    return;
                }
                if (now - sample.since < 4000 || now < sample.retryAt || sample.retries >= 3) return;
                // Read geometry only before recovery, never on a healthy timeline.
                const rootStyle = getComputedStyle(root);
                const style = getComputedStyle(target, effect.pseudoElement || null);
                const index = style.animationName.split(',').map(value => value.trim()).indexOf(animation.animationName);
                const states = style.animationPlayState.split(',').map(value => value.trim());
                if (!root.getClientRects().length || !target.getClientRects().length ||
                    rootStyle.visibility === 'hidden' || Number(rootStyle.opacity) === 0 ||
                    index < 0 || states[index % states.length] === 'paused') {
                    samples.delete(animation);
                    return;
                }
                // Rebind a stuck timeline at its current phase, never restart the effect.
                sample.retries++;
                sample.retryAt = now + 30000;
                try {
                    animation.pause();
                    animation.currentTime = time;
                    animation.play();
                } catch (_) {}
            });
        });
        samples.forEach(function (_, animation) {
            if (!seen.has(animation)) samples.delete(animation);
        });
    }

    function reset() { samples.clear(); previousTick = 0; }
    function start() {
        if (disposed || timer || (!selected('goal') && !selected('donatel'))) return;
        timer = window.KaspiWidgetRuntime ? window.KaspiWidgetRuntime.every(tick, 2000, ['goal', 'donatel']) : setInterval(tick, 2000);
        tick();
    }
    window.KaspiWidgetContinuity = { reset: reset };
    document.addEventListener('visibilitychange', reset);
    window.addEventListener('pageshow', function () { suspended = false; reset(); start(); });
    window.addEventListener('pagehide', function (event) {
        suspended = true;
        if (typeof timer === 'function') timer(); else clearInterval(timer);
        timer = 0;
        reset();
        if (!event.persisted) disposed = true;
    });
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start, { once: true });
    else start();
})();
