(function () {
    'use strict';
    if (window.KaspiWidgetMotion) return;

    const tracked = new Map();
    const videoPattern = /\.(mp4|webm|mov|m4v)$/i;
    let timer = 0;
    let disposed = false;

    function syncTimer() {
        if (disposed) return;
        if (tracked.size && !timer) {
            timer = window.KaspiWidgetRuntime ? window.KaspiWidgetRuntime.every(tick, 1500, ['top']) : setInterval(tick, 1500);
        } else if (!tracked.size && timer) {
            if (typeof timer === 'function') timer(); else clearInterval(timer);
            timer = 0;
        }
    }

    function play(video, state) {
        if (state.playPending) return;
        state.playPending = true;
        try {
            Promise.resolve(video.play()).catch(function () {}).finally(function () {
                state.playPending = false;
            });
        } catch (_) { state.playPending = false; }
    }

    function isShown(video) {
        if (window.KaspiWidgetRuntime && !window.KaspiWidgetRuntime.active(['top'])) return false;
        if (!video.getClientRects().length) return false;
        if (document.body.classList.contains('youtube-active') &&
            video.closest('.left-column, .goal-wrapper, .kaspi-banner, #monthTickerContainer')) return false;
        return true;
    }

    function watch(video) {
        if (tracked.has(video) || !video.loop || !video.muted) return;
        const state = { time: video.currentTime, changedAt: performance.now(), retryAt: 0,
            retries: 0, suspended: false, playPending: false, source: video.getAttribute('src') };
        video.preload = 'auto';
        video.playsInline = true;
        const onEnded = function () {
            if (!video.isConnected || !video.loop || !video.muted || !isShown(video)) return;
            // Native loop normally handles this without seeking or an ended event.
            if (video.ended) video.currentTime = 0;
            play(video, state);
        };
        video.addEventListener('ended', onEnded);
        state.dispose = function () {
            video.removeEventListener('ended', onEnded);
            if (state.onMetadata) video.removeEventListener('loadedmetadata', state.onMetadata);
        };
        tracked.set(video, state);
        syncTimer();
    }

    function release(host) {
        host.querySelectorAll('video').forEach(function (video) {
            const state = tracked.get(video);
            if (state) state.dispose();
            tracked.delete(video);
            video.pause();
            video.removeAttribute('src');
            video.load();
        });
        host.replaceChildren();
        syncTimer();
    }

    function syncMedia(host, value, className) {
        const url = String(value || '').trim();
        const clean = url.split('?')[0];
        if (!/^\/top-cs2-media\/[A-Za-z0-9._-]+$/.test(clean)) {
            if (host.firstElementChild) release(host);
            return null;
        }
        const isVideo = videoPattern.test(clean);
        const old = host.firstElementChild;
        if (old && old.tagName === (isVideo ? 'VIDEO' : 'IMG') && old.getAttribute('src') === url) return old;
        release(host);
        const media = document.createElement(isVideo ? 'video' : 'img');
        media.draggable = false;
        if (className && (isVideo || /\.gif$/i.test(clean))) media.className = className;
        if (isVideo) {
            media.autoplay = true;
            media.loop = true;
            media.muted = true;
            media.defaultMuted = true;
            media.playsInline = true;
            media.preload = 'auto';
            media.setAttribute('muted', '');
            media.setAttribute('playsinline', '');
        } else {
            media.alt = '';
            media.decoding = 'async';
        }
        media.src = url;
        host.appendChild(media);
        if (isVideo) watch(media);
        return media;
    }

    function syncSlots(layer, titleLayer, config, hideRows, visibleRows) {
        const count = Number.isInteger(visibleRows) ? Math.max(0, Math.min(5, visibleRows)) : 5;
        const title = syncMedia(titleLayer, config.cs2_media_title, 'cs2-animated-media');
        titleLayer.classList.toggle('has-media', Boolean(title));
        for (let i = 1; i <= 5; i++) {
            let slot = layer.querySelector('[data-slot="' + i + '"]');
            if (!slot) {
                slot = document.createElement('span');
                slot.className = 'cs2-media-slot';
                slot.dataset.slot = String(i);
                layer.appendChild(slot);
            }
            syncMedia(slot, hideRows || i > count ? '' : config['cs2_media_' + i], 'cs2-animated-media');
        }
        let empty = layer.querySelector('[data-empty-slot]');
        if (!empty) {
            empty = document.createElement('span');
            empty.className = 'cs2-media-slot cs2-empty-media-slot';
            empty.dataset.emptySlot = '1';
            empty.style.cssText = 'position:absolute;left:0;top:0;display:none;';
            layer.appendChild(empty);
        }
        const emptyUrl = visibleRows === undefined || count === 0 ? config.cs2_media_empty : '';
        empty.dataset.hasMedia = syncMedia(empty, emptyUrl, 'cs2-animated-media') ? '1' : '0';
    }

    function tick() {
        const now = performance.now();
        tracked.forEach(function (state, video) {
            if (!video.isConnected || !video.loop || !video.muted) {
                state.dispose();
                tracked.delete(video);
                if (!video.isConnected) video.pause();
                return;
            }
            if (!isShown(video)) {
                state.suspended = true;
                video.dataset.shouldPlay = '0';
                if (!video.paused) video.pause();
                state.changedAt = now;
                return;
            }
            video.dataset.shouldPlay = '1';
            const source = video.getAttribute('src');
            if (state.suspended || source !== state.source || Math.abs(video.currentTime - state.time) > .01) {
                state.changedAt = now;
                state.time = video.currentTime;
                state.source = source;
                state.retries = 0;
                state.suspended = false;
            }
            if (video.paused || video.ended) {
                if (video.ended) video.currentTime = 0;
                play(video, state);
            }
            // A stalled decoder is different from a busy compositor. Never seek
            // or reload healthy playback, and never touch YouTube or donation audio.
            const stallTimeout = video.readyState >= 2 ? 6000 : 12000;
            if (now - state.changedAt < stallTimeout || now < state.retryAt || video.seeking) return;
            let local = false;
            try { local = new URL(video.currentSrc || video.src, location.href).origin === location.origin; } catch (_) {}
            if (!local || state.retries >= 3) return;
            state.retries++;
            state.retryAt = now + 15000 * state.retries;
            state.changedAt = now;
            state.playPending = false;
            const position = video.currentTime;
            if (state.onMetadata) video.removeEventListener('loadedmetadata', state.onMetadata);
            state.onMetadata = function () {
                state.onMetadata = null;
                if (!video.isConnected || video.getAttribute('src') !== source) return;
                if (Number.isFinite(video.duration) && position < video.duration) video.currentTime = position;
                if (video.isConnected && isShown(video)) play(video, state);
            };
            video.addEventListener('loadedmetadata', state.onMetadata, { once: true });
            video.load();
        });
        syncTimer();
    }

    function scan(node) {
        if (!node || node.nodeType !== 1) return;
        if (node.tagName === 'VIDEO') watch(node);
        node.querySelectorAll('video').forEach(watch);
    }

    function resumeAfterYoutube() {
        // Synchronous and idempotent: no delayed cleanup can unhide the next video.
        document.body.classList.remove('youtube-active', 'animations-resetting');
        if (window.KaspiWidgetPerformance) window.KaspiWidgetPerformance.reset();
        tick();
    }

    function start() {
        if (window.KaspiWidgetRuntime && !window.KaspiWidgetRuntime.shows('top')) return;
        scan(document.body);
        const observer = new MutationObserver(function (records) {
            records.forEach(function (record) {
                if (record.type === 'attributes' && record.target.tagName === 'VIDEO') watch(record.target);
                else record.addedNodes.forEach(scan);
            });
        });
        observer.observe(document.body, { childList: true, subtree: true, attributes: true,
            attributeFilter: ['src', 'loop', 'muted'] });
        let youtubeActive = document.body.classList.contains('youtube-active');
        const visibilityObserver = new MutationObserver(function () {
            const next = document.body.classList.contains('youtube-active');
            if (next === youtubeActive) return;
            youtubeActive = next;
            if (window.KaspiWidgetPerformance) window.KaspiWidgetPerformance.reset();
            tick();
        });
        visibilityObserver.observe(document.body, { attributes: true, attributeFilter: ['class'] });
        syncTimer();
        window.KaspiWidgetRuntime?.subscribe(tick);
        window.addEventListener('pageshow', tick);
        document.addEventListener('visibilitychange', tick);
        window.addEventListener('pagehide', function (event) {
            if (event.persisted) return;
            disposed = true;
            if (typeof timer === 'function') timer(); else clearInterval(timer);
            observer.disconnect();
            visibilityObserver.disconnect();
            tracked.forEach(function (state) { state.dispose(); });
            tracked.clear();
        });
        tick();
    }

    async function fetchJson(url, options) {
        const controller = new AbortController();
        const timeout = setTimeout(function () { controller.abort(); }, 6000);
        try {
            const response = await fetch(url, Object.assign({}, options, { signal: controller.signal }));
            if (!response.ok) throw new Error('HTTP ' + response.status);
            return await response.json();
        } finally { clearTimeout(timeout); }
    }

    window.KaspiWidgetMotion = { syncMedia: syncMedia, syncSlots: syncSlots, release: release,
        refresh: tick, resumeAfterYoutube: resumeAfterYoutube, fetchJson: fetchJson };
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start, { once: true });
    else start();
})();
