(function () {
    'use strict';
    let banner = null, stage = null, observer = null, fitJob = 0;
    let numberValue = null, nameValue = null;
    function fit() {
        fitJob = 0;
        if (!stage?.isConnected) return;
        let zoom = 1;
        for (let node = banner; node; node = node.parentElement) {
            const value = parseFloat(getComputedStyle(node).zoom);
            if (Number.isFinite(value) && value > 0) zoom *= value;
        }
        const width = stage.offsetWidth + 10;
        banner.style.setProperty('--kaspi-long-fit', Math.max(.05, Math.min(1.6, (innerWidth - 24) / (width * zoom))));
    }
    function scheduleFit() {
        if (!fitJob && stage) fitJob = requestAnimationFrame(fit);
    }
    function dispose() {
        observer?.disconnect(); observer = null;
        cancelAnimationFrame(fitJob); fitJob = 0;
        stage?.remove(); stage = null;
        banner?.style.removeProperty('--kaspi-long-fit');
        banner = null; numberValue = null; nameValue = null;
    }
    function configure(style, host = document.querySelector('.kaspi-banner')) {
        if (style?.template !== 'kaspi_long' || !host) {dispose(); return;}
        if (banner !== host) dispose();
        banner = host;
        banner.style.setProperty('--kaspi-long-icon', Math.max(32, Math.min(96, Number(style.icon_size) || 60)) + 'px');
        banner.style.setProperty('--kaspi-long-font', Math.max(16, Math.min(64, Number(style.font_size) || 30)) + 'px');
        if (!stage) {
            stage = document.createElement('span');
            stage.className = 'kaspi-long-stage';
            stage.setAttribute('role', 'img');
            stage.innerHTML = '<span class="kaspi-long-mark" aria-hidden="true"><img src="/static/brands/kaspi.svg" alt="" width="141" height="33"></span>'
                + '<span class="kaspi-long-copy" aria-hidden="true"><span class="kaspi-long-label">Kaspi <b>Gold</b></span>'
                + '<span class="kaspi-long-digits"></span><span class="kaspi-long-name"></span>'
                + '<span class="kaspi-long-line"></span><span class="kaspi-long-glint"></span></span>';
            banner.appendChild(stage);
            if (typeof ResizeObserver === 'function') {
                observer = new ResizeObserver(scheduleFit);
                observer.observe(stage);
            }
            document.fonts?.ready.then(scheduleFit);
        }
        const number = String(style.kaspi_number || '').trim() || 'Укажи номер Kaspi';
        const name = String(style.kaspi_name || '').trim();
        // Polling and unrelated settings must not rebuild the animated digits.
        if (numberValue !== number) {
            const digits = stage.querySelector('.kaspi-long-digits');
            const fragment = document.createDocumentFragment();
            Array.from(number).forEach((value, index) => {
                const digit = document.createElement('span');
                digit.textContent = value;
                digit.style.setProperty('--digit-step', Math.min(index, 24));
                fragment.appendChild(digit);
            });
            digits.replaceChildren(fragment);
            numberValue = number;
        }
        if (nameValue !== name) {
            const recipient = stage.querySelector('.kaspi-long-name');
            recipient.textContent = name;
            recipient.hidden = !name;
            nameValue = name;
        }
        stage.setAttribute('aria-label', ['Kaspi Gold', number, name].filter(Boolean).join(', '));
        scheduleFit();
    }
    addEventListener('resize', scheduleFit);
    addEventListener('pagehide', dispose);
    window.KaspiLong = {configure, dispose};
})();
