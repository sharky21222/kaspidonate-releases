# Bank Marks

- `alif.svg`: Alif's published product wordmark, downloaded from https://alifwebsite.alif.tj/uploads/Alif_Products_Logo_2c30cc792e.svg on 2026-10-18. Used to identify the bank; all trademark rights remain with Alif.
- `dc-next.png` and `tbank.png`: existing bank marks already bundled with KaspiDonate.
