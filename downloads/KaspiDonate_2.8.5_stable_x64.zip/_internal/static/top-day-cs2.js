(function () {
    'use strict';
    let frame = 0;
    const cache = new WeakMap();
    const titleCache = new WeakMap();

    function fit() {
        frame = 0;
        const root = document.querySelector('#leftColumn.template-cs2');
        if (!root) return;
        const entries = Array.from(root.querySelectorAll('.top-donation-item')).map(row => {
            const sender = row.querySelector('.top-donation-sender');
            const name = row.querySelector('.sender-name');
            const amount = row.querySelector('.top-donation-amount');
            if (!sender || !name || !amount) return null;
            const key = [name.textContent, amount.textContent, row.clientWidth,
                getComputedStyle(sender).fontFamily,
                getComputedStyle(root).getPropertyValue('--top-nick-size'),
                getComputedStyle(root).getPropertyValue('--top-amount-size')].join('|');
            const previous = cache.get(row);
            if (previous && previous.key === key && previous.name === name && previous.amount === amount
                && !name.style.getPropertyValue('font-size') && !name.style.getPropertyValue('transform')
                && !amount.style.getPropertyValue('font-size')) return null;
            return { row, sender, name, amount, key };
        }).filter(Boolean);
        entries.forEach(({sender, name, amount}) => {
            sender.classList.remove('cs2-long-name');
            name.style.removeProperty('font-size');
            name.style.removeProperty('transform');
            amount.style.removeProperty('font-size');
            name.style.removeProperty('--cs2-fit-name');
            amount.style.removeProperty('--cs2-fit-amount');
        });
        const amounts = entries.map(entry => ({...entry,
            size: parseFloat(getComputedStyle(entry.amount).fontSize),
            width: entry.amount.scrollWidth,
            available: entry.amount.clientWidth
        }));
        amounts.forEach(({amount, size, width, available}) => {
            if (width > available && available > 0) {
                amount.style.setProperty('--cs2-fit-amount', Math.max(16, size * available / width * .98) + 'px');
            }
        });
        const names = entries.map(entry => ({...entry,
            size: parseFloat(getComputedStyle(entry.sender).fontSize),
            width: entry.name.scrollWidth, available: entry.sender.clientWidth
        }));
        names.forEach(({row, sender, name, amount, key, size, width, available}) => {
            if (available < 1) return;
            const fitted = width > available ? Math.max(16, size * available / width * .98) : size;
            name.style.setProperty('--cs2-fit-name', fitted.toFixed(2) + 'px');
            const travel = width * fitted / size - available;
            if (travel > 3) {
                name.style.setProperty('--cs2-name-travel', Math.ceil(travel + 4) + 'px');
                name.style.setProperty('--cs2-name-duration', Math.max(7, Math.min(18, travel / 20 + 5)) + 's');
                sender.classList.add('cs2-long-name');
            }
            sender.title = name.textContent;
            cache.set(row, {key, name, amount});
        });
        const title = root.querySelector('.top-donations-title');
        if (title) {
            const titleKey = [title.textContent, title.clientWidth,
                getComputedStyle(root).getPropertyValue('--top-title-size')].join('|');
            if (titleCache.get(title) === titleKey) return;
            title.style.removeProperty('--cs2-fit-title');
            const size = parseFloat(getComputedStyle(title).fontSize);
            const text = document.createRange();
            text.selectNodeContents(title);
            const scale = title.getBoundingClientRect().width / title.offsetWidth || 1;
            const width = text.getBoundingClientRect().width / scale;
            if (width > title.clientWidth - 40) {
                title.style.setProperty('--cs2-fit-title', Math.max(14, size * (title.clientWidth - 40) / width) + 'px');
            }
            titleCache.set(title, titleKey);
        }
    }

    function scheduleFit() {
        if (window.KaspiWidgetRuntime && !window.KaspiWidgetRuntime.active(['top'])) return;
        if (frame) cancelAnimationFrame(frame);
        frame = requestAnimationFrame(fit);
    }
    window.KaspiCs2 = { scheduleFit: scheduleFit };
    window.addEventListener('resize', scheduleFit, {passive:true});
    document.addEventListener('DOMContentLoaded', scheduleFit, {once:true});
    if (document.fonts && document.fonts.ready) document.fonts.ready.then(function () {
        const root = document.querySelector('#leftColumn.template-cs2');
        if (root) {
            root.querySelectorAll('.top-donation-item').forEach(row => cache.delete(row));
            const title = root.querySelector('.top-donations-title');
            if (title) titleCache.delete(title);
        }
        scheduleFit();
    });
})();
