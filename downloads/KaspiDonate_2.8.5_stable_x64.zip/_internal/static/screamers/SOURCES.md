# Horror Vocal Pack

Pack version: `20261006-1`. Twelve distinct MP3 clips, 2.1-3.2 seconds each.
Built-in IDs stay unchanged. Custom uploads, selected sounds, their order,
thresholds in KZT/RUB and volume are not modified. Playback is local.

## Sources

All recordings use CC0. Public HQ audio previews were downloaded after checking
the dedication on each source page. Exact excerpts, profiles and hashes are
in `sources.json`.

- `demon_scream.mp3`: Jumpscare Scream, Breviceps.
  https://freesound.org/people/Breviceps/sounds/587354/
- `girl_scream.mp3`: Girl_Scream.wav, tcrocker68.
  https://freesound.org/people/tcrocker68/sounds/235592/
- `woman_scream.mp3`: Female Scream 2, DRFX.
  https://freesound.org/people/DRFX/sounds/398278/
- `horror_shriek.mp3`: Jumpscare Sound 2, Kierham.
  https://freesound.org/people/Kierham/sounds/570457/
- `distorted_scream.mp3`: Zombie Demon Scream, Wakerone.
  https://freesound.org/people/Wakerone/sounds/435651/
- `nightmare.mp3`: Creepy Ghost Scream, epicdude959.
  https://freesound.org/people/epicdude959/sounds/352508/
- `piercing.mp3`: Scream.mp3, Topschool.
  https://freesound.org/people/Topschool/sounds/360464/
- `ghost_breath.mp3`: second take from Horror shrieks woman, AderuMoro;
  mixed with a pitch-shifted copy and short echoes.
  https://freesound.org/people/AderuMoro/sounds/320740/
- `alien_scream.mp3`: Woman Scream, NachtmahrTV; processed vocal layer.
  https://freesound.org/people/NachtmahrTV/sounds/618112/
- `monster_attack.mp3` and `monster_death.mp3`: two separate takes from
  male scream pain torture.wav, martian, a professional actor's recording.
  https://freesound.org/people/martian/sounds/530471/
- `monster_roar.mp3`: scream.mp3, winsx87; pitch-shifted with a short echo.
  https://freesound.org/people/winsx87/sounds/152019/

CC0: https://creativecommons.org/publicdomain/zero/1.0/
These are licensed sound effects, not audio ripped from horror films.
Audience reactions cannot be guaranteed. Preview at a low volume first.

## Build and Verification

`scripts/prepare_screamer_horror.py` stages files before installation.
It trims leading silence, filters the vocal range, applies bounded compression,
adds edge fades and uses measured two-pass normalization. Effects are baked
into the clips; the live widget has no extra processing workload.

Decoded MP3 measurements: -15.64 to -11.43 LUFS, true peaks no higher than
-2.67 dBTP. Mono 44.1 kHz, 160 kbps, 43-65 KB per file. No volume setting is
raised automatically. Twelve SHA-256 hashes are distinct.

Previous audio and attribution are backed up in
`.codex-artifacts/screamers-20261006-horror/previous`.
Compatibility aliases `horror_sting`, `horror_scream`, `horror_jumpscare`
point to the demon, girl and distorted clips respectively.

Catalog and audio URLs are versioned. After changing `catalog.json`, run
`node scripts/build_screamer_catalog.cjs` to regenerate browser and desktop
catalogs. Server-side donation assignment, sequential/shuffle modes and
restart-persistent cursors stay unchanged.
