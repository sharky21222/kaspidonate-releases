(function (root, factory) {
    const library = factory(root?.KaspiScreamerCatalog || (typeof require === 'function' ? require('./screamer-catalog.js') : null));
    if (typeof module === 'object' && module.exports) module.exports = library;
    if (root) root.KaspiScreamerLibrary = library;
})(typeof window !== 'undefined' ? window : null, function (catalog) {
    'use strict';

    const customPattern = /^screamer-[0-9]+-[a-z0-9]{1,8}\.(mp3|wav|ogg|m4a|aac|flac|webm|opus)$/;
    const sounds = Object.freeze(catalog.sounds.map(item => item.file));
    const maxCustomSounds = 64;
    const maxGainDb = 48;

    function customSounds(config) {
        const seen = new Set();
        return (Array.isArray(config?.custom_sounds) ? config.custom_sounds : []).filter(item => {
            if (!item || typeof item.file !== 'string' || !customPattern.test(item.file) || seen.has(item.file)) return false;
            seen.add(item.file);
            return true;
        }).slice(0, maxCustomSounds).map(item => ({
            file: item.file,
            name: String(item.name || item.file).slice(0, 100),
            custom: true
        }));
    }

    function entries(config) {
        const removed = new Set(Array.isArray(config?.removed_sounds) ? config.removed_sounds : []);
        return [...catalog.sounds.filter(item => !removed.has(item.file)), ...customSounds(config)];
    }

    function activeSounds(config) {
        const available = new Set(entries(config).map(item => item.file));
        const selected = Array.isArray(config?.sounds) ? config.sounds : [];
        const pool = [...new Set(selected.filter(sound => available.has(sound)))];
        return pool.length ? pool : sounds.filter(sound => available.has(sound));
    }

    function boostDb(config) {
        const value = Number(config?.gain_db);
        return Number.isFinite(value) ? Math.max(0, Math.min(maxGainDb, Math.round(value))) : 0;
    }

    function soundVolume(sound, config) {
        const value = config?.sound_volumes?.[sound];
        if (!['number', 'string'].includes(typeof value) || String(value).trim() === '') return 1;
        const level = Number(value);
        return Number.isFinite(level) ? Math.max(0, Math.min(1, level)) : 1;
    }

    function volumeForSound(sound, config) {
        const level = Number(config?.volume);
        return (Number.isFinite(level) ? Math.max(0, Math.min(1, level)) : 0.8) * soundVolume(sound, config);
    }

    function urlForSound(sound, config) {
        const bundled = sounds.includes(sound) && entries(config).some(item => item.file === sound);
        const custom = customSounds(config).some(item => item.file === sound);
        if (!bundled && !custom) return null;
        const gain = boostDb(config);
        if (gain > 0) return '/screamer-media/' + encodeURIComponent(sound) + '?gain_db=' + gain + '&v=' + catalog.version;
        if (bundled) return '/static/screamers/' + encodeURIComponent(sound) + '?v=' + catalog.version;
        if (custom) return '/screamer-media/' + encodeURIComponent(sound);
        return null;
    }

    return { sounds, entries, customSounds, activeSounds, urlForSound, boostDb, maxCustomSounds, maxGainDb, soundVolume, volumeForSound };
});
