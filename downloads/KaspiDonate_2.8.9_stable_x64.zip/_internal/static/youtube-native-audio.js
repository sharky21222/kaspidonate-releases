(() => {
  'use strict';
  const query = new URLSearchParams(location.search);
  const requestId = query.get('request_id'), claimId = query.get('claim_id');
  const audio = document.createElement('audio');
  audio.preload = 'auto'; document.body.append(audio);
  let order, remaining = 0, lastPosition = 0, started = false, finished = false, loading = false;
  let busy = false, command = '', wantedPause = false, sampleAt = performance.now(), heartbeatAt = 0;
  async function json(url, data) {
    const controller = new AbortController(), timeout = setTimeout(() => controller.abort(), 20000);
    try {
      const response = await fetch(url, {cache: 'no-store', signal: controller.signal,
        ...(data ? {method: 'POST', headers: {'Content-Type': 'application/json'}, body: JSON.stringify(data)} : {})});
      if (!response.ok) throw new Error('HTTP ' + response.status);
      return await response.json();
    } finally {clearTimeout(timeout);}
  }
  const report = (action, reason = '') => json('/api/youtube_music_orders', {
    action, reason, requestId, claimId, playbackTracked: true,
    position: audio.currentTime || 0, remainingMs: remaining,
  });
  function stop() { finished = true; audio.pause(); audio.removeAttribute('src'); audio.load(); }
  async function finish(action, reason) {
    if (finished) return;
    finished = true;
    audio.pause();
    for (let attempt = 0; attempt < 3; attempt++) {
      try {await report(action, reason); return;} catch (_) {await new Promise(resolve => setTimeout(resolve, 1000));}
    }
  }
  async function poll() {
    if (busy || finished) return;
    busy = true;
    try {
      const state = await json('/api/youtube_playback');
      if (state.reserved?.requestId !== requestId || state.reserved?.claimId !== claimId) {stop(); return;}
      audio.volume = Math.max(0, Math.min(1, Number(state.volume) || 0));
      if (!order && !loading) {
        loading = true;
        order = state.reserved;
        remaining = Math.max(0, Number(order.remainingDurationMs ?? order.durationMs ?? 180000));
        const stream = await json('/api/yt_stream/' + encodeURIComponent(order.videoId) + '?audio_only=1');
        if (!stream.audio_url || !stream.audio_proxy_url) throw new Error(stream.error || 'No audio stream');
        audio.src = stream.audio_proxy_url;
        audio.addEventListener('loadedmetadata', () => {
          if (Number(order.startSeconds) > 0) audio.currentTime = Number(order.startSeconds);
          if (!wantedPause) audio.play().catch(error => finish('failed', 'Native audio: ' + error.message));
        }, {once: true});
        audio.load();
        loading = false;
      }
      const control = state.control;
      if (control?.id && control.id !== command && control.requestId === requestId && (!control.claimId || control.claimId === claimId)) {
        command = control.id;
        if (control.action === 'pause') {wantedPause = true; audio.pause();}
        if (control.action === 'resume') {wantedPause = false; await audio.play();}
        if (control.action === 'stop' || control.action === 'next') await finish('stopped', 'manual_stop');
      }
      if (started && Date.now() - heartbeatAt > 1200) {
        heartbeatAt = Date.now();
        const response = await report('heartbeat');
        if (response.status === 'not_found') stop();
      }
    } catch (error) {
      if (!started) finish('failed', 'Native audio: ' + error.message);
    } finally {busy = false;}
  }
  audio.addEventListener('playing', () => {
    if (!started && !finished) {started = true; report('started').catch(() => {started = false;});}
    sampleAt = performance.now(); lastPosition = audio.currentTime || 0;
  });
  audio.addEventListener('ended', () => finish('completed', 'ended'));
  audio.addEventListener('error', () => {if (!finished) finish('failed', 'Native media error ' + (audio.error?.code || 0));});
  const sample = setInterval(() => {
    const now = performance.now(), elapsed = now - sampleAt, position = audio.currentTime || 0;
    if (started && !audio.paused && position > lastPosition)
      remaining = Math.max(0, remaining - Math.min((position - lastPosition) * 1000, elapsed + 500));
    sampleAt = now; lastPosition = position;
    if (started && remaining <= 0) finish('completed', 'duration_limit');
  }, 250);
  const timer = setInterval(poll, 650);
  addEventListener('pagehide', () => {clearInterval(timer); clearInterval(sample); stop();});
  poll();
})();
