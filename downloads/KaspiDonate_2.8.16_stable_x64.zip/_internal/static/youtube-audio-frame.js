(function () {
    'use strict';

    const WIDTH = 320;
    const HEIGHT = 72;
    let selected = false;
    let readState = () => ({});
    let timer = null;
    let scene = null;
    let name = null;
    let lastName = null;

    const initialPreview = window.__KASPI_PREVIEW__ && new URLSearchParams(window.location.search).get('yt_template');
    selected = (initialPreview || window.youtubeTemplate) === 'audio_frame';
    if (selected && window.KaspiWidgetRuntime?.shows('youtube')) {
        document.documentElement.classList.add('youtube-audio-template');
    }

    function ensureScene() {
        if (scene) return true;
        const widget = document.getElementById('youtubeWidget');
        if (!widget) return false;
        scene = document.createElement('section');
        scene.className = 'youtube-audio-scene';
        scene.hidden = true;
        scene.setAttribute('aria-label', 'Музыкальный заказ');
        scene.innerHTML = '<div class="youtube-audio-icon" aria-hidden="true">&#9835;</div>'
            + '<div class="youtube-audio-name"></div>'
            + '<div class="youtube-audio-meter" role="img" aria-label="Индикатор воспроизведения"></div>';
        const meter = scene.querySelector('.youtube-audio-meter');
        for (let i = 0; i < 5; i++) {
            const bar = document.createElement('i');
            bar.style.setProperty('--bar-height', `${8 + (i * 7 % 15)}px`);
            bar.style.setProperty('--bar-speed', `${660 + (i * 137 % 700)}ms`);
            bar.style.setProperty('--bar-delay', `${-i * 113}ms`);
            meter.appendChild(bar);
        }
        name = scene.querySelector('.youtube-audio-name');
        widget.appendChild(scene);
        fit();
        return true;
    }

    function fit() {
        if (!scene) return;
        let zoom = 1;
        for (let el = scene.parentElement; el; el = el.parentElement) {
            const value = parseFloat(getComputedStyle(el).zoom);
            if (Number.isFinite(value) && value > 0) zoom *= value;
        }
        const scale = Math.max(0.05, Math.min(1, (window.innerWidth - 16) / WIDTH, (window.innerHeight - 16) / HEIGHT)) / zoom;
        scene.style.transform = `translate(-50%, -50%) scale(${scale})`;
    }

    function stopTimer() {
        if (typeof timer === 'function') timer();
        else if (timer !== null) clearInterval(timer);
        timer = null;
    }

    function sync() {
        const state = readState() || {};
        const enabled = selected && state.view === true;
        const idlePreview = enabled && !state.active && window.__KASPI_PREVIEW__;
        document.documentElement.classList.toggle('youtube-audio-template', enabled);
        document.documentElement.classList.toggle('youtube-audio-preview', Boolean(enabled && window.__KASPI_PREVIEW__));
        if (!enabled || (!state.active && !idlePreview)) {
            if (scene) { scene.hidden = true; scene.classList.remove('is-playing'); }
            if (!enabled) stopTimer();
            return enabled;
        }
        if (!ensureScene()) return enabled;
        scene.hidden = false;
        const sender = idlePreview ? 'Имя донатера' : String(state.sender || 'Аноним');
        if (sender !== lastName) {
            lastName = sender;
            name.textContent = sender;
            name.title = sender;
            name.style.fontSize = '21px';
            let size = 21;
            while (size > 14 && name.scrollWidth > name.clientWidth) name.style.fontSize = `${--size}px`;
        }
        const muted = Number(state.volume) <= 0;
        const paused = state.paused || state.playerState === 2;
        const playing = !idlePreview && state.playerState === 1 && !paused && !muted;
        // Playback activity, not a fabricated audio spectrum. No extra media or AudioContext.
        scene.classList.toggle('is-playing', playing);
        return enabled;
    }

    function configure(config, getState) {
        if (typeof getState === 'function') readState = getState;
        const preview = window.__KASPI_PREVIEW__ && new URLSearchParams(window.location.search).get('yt_template');
        selected = (preview || config?.youtube_template) === 'audio_frame';
        if (sync() && timer === null) timer = window.KaspiWidgetRuntime
            ? window.KaspiWidgetRuntime.every(sync, 250, ['youtube']) : setInterval(sync, 250);
    }

    window.addEventListener('resize', fit);
    window.addEventListener('hashchange', sync);
    window.addEventListener('pagehide', stopTimer);
    window.KaspiYoutubeAudioFrame = { configure, sync };
})();
