(() => {
  'use strict';
  function create({host, videoId, requestId, streamData, startSeconds = 0, volume, onPlaying, onEnded, onError}) {
    const video = document.createElement('video');
    video.id = 'ytpicture'; video.muted = true; video.playsInline = true; video.preload = 'auto';
    video.style.cssText = 'width:100%;height:100%;object-fit:contain;background:#000;pointer-events:none';
    video.src = streamData.video_proxy_url || streamData.video_url;
    const sound = document.createElement('div'); sound.hidden = true;
    host.replaceChildren(video, sound);
    let closed = false, ready = false, timer, audio;
    function dispose() {
      if (closed) return;
      closed = true; clearInterval(timer); audio?.destroy();
      video.pause(); video.removeAttribute('src'); video.load(); video.remove(); sound.remove();
    }
    function fail(reason) {if (!closed) {dispose(); onError(reason);}}
    video.addEventListener('error', () => fail('Video proxy error: ' + (video.error?.code || 0)));
    video.addEventListener('loadedmetadata', () => {
      ready = true;
      if (startSeconds > 0) video.currentTime = startSeconds;
    });
    audio = window.KaspiYoutubeAudioPlayer.create({host: sound, videoId, requestId, startSeconds, volume,
      onPlaying: () => {if (!closed) {video.muted = true; video.play().catch(() => {}); onPlaying();}},
      onEnded: () => {if (!closed) {dispose(); onEnded();}}, onError: fail});
    timer = setInterval(() => {
      if (closed || !ready) return;
      const state = audio.getPlayerState(), position = Number(audio.getCurrentTime()) || 0;
      if (state !== 1) {video.pause(); return;}
      if (Math.abs(video.currentTime - position) > .7) video.currentTime = position;
      video.muted = true;
      if (video.paused) video.play().catch(() => {});
    }, 300);
    video.load();
    return { _video: audio._video, getPlayerState: () => audio.getPlayerState(),
      getCurrentTime: () => audio.getCurrentTime(), getDuration: () => Number(streamData.duration) || video.duration || 0,
      playVideo: () => audio.playVideo(), pauseVideo: () => {video.pause(); audio.pauseVideo();},
      setVolume: value => audio.setVolume(value), mute: () => audio.mute(), unMute: () => audio.unMute(),
      destroy: dispose, stopVideo: dispose, setPlaybackQuality: () => {} };
  }
  // A picture can follow an existing sound owner without claiming the order again.
  function attach({host, player, streamData, onError = () => {}, onPlaying = () => {}}) {
    const video = document.createElement('video');
    video.id = 'ytpicture'; video.muted = true; video.playsInline = true; video.preload = 'auto';
    video.style.cssText = 'width:100%;height:100%;object-fit:contain;pointer-events:none';
    const url = new URL(streamData.video_proxy_url || streamData.video_url, location.href);
    if (!['http:', 'https:'].includes(url.protocol)) throw new Error('Invalid video URL');
    let closed = false, ready = false, pendingPlay = false, timer;
    function dispose() {
      if (closed) return;
      closed = true; clearInterval(timer);
      video.pause(); video.removeAttribute('src'); video.load(); video.remove();
    }
    function sync() {
      if (closed || !ready) return;
      const position = Math.max(0, Number(player.getCurrentTime?.()) || 0);
      if (Math.abs(video.currentTime - position) > .45) {
        try {video.currentTime = position;} catch (_) {}
      }
      video.muted = true;
      if (player.getPlayerState?.() !== 1) {video.pause(); return;}
      if (video.paused && !pendingPlay) {
        pendingPlay = true;
        video.play().catch(error => {
          if (!closed && error.name !== 'AbortError') {dispose(); onError('Video playback: ' + error.message);}
        }).finally(() => {pendingPlay = false;});
      }
    }
    video.addEventListener('loadedmetadata', () => {ready = true; sync();});
    video.addEventListener('playing', () => {if (!closed) onPlaying();});
    video.addEventListener('error', () => {
      if (!closed) {const code = video.error?.code || 0; dispose(); onError('Video proxy error: ' + code);}
    });
    host.replaceChildren(video);
    video.src = url.href; video.load();
    timer = setInterval(sync, 250);
    return {destroy: dispose, sync};
  }
  window.KaspiYoutubeVideoPlayer = {create, attach};
})();
